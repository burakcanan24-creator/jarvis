# tests/run_regression.py
import time
import requests
from typing import List, Dict, Any

BASE_URL = "http://127.0.0.1:8000/chat"
SESSION_ID = "burak"
TIMEOUT = 10


def send(text: str) -> str:
    r = requests.post(
        BASE_URL,
        json={"session_id": SESSION_ID, "text": text},
        timeout=TIMEOUT,
    )
    r.raise_for_status()
    return (r.json() or {}).get("reply", "").lower()


def expect_contains(reply: str, expect: List[str]) -> bool:
    return any(e.lower() in reply for e in expect)


def reject_contains(reply: str, reject: List[str]) -> bool:
    return any(r.lower() in reply for r in reject)


def run_test(case: Dict[str, Any]) -> bool:
    reply = send(case["text"])
    ok_expect = expect_contains(reply, case.get("expect", []))
    ok_reject = not reject_contains(reply, case.get("reject", []))

    status = "PASS" if ok_expect and ok_reject else "FAIL"
    print(f"[{case['id']}] {status}")
    print(f"  USER   : {case['text']}")
    print(f"  JARVIS : {reply}")

    if not ok_expect:
        print(f"  ❌ Beklenenlerden biri yok: {case.get('expect')}")
    if not ok_reject:
        print(f"  ❌ Yasaklı içerik var: {case.get('reject')}")

    print("-" * 50)
    return status == "PASS"


TESTS: List[Dict[str, Any]] = [

    # ===== A) TOOLS =====
    {"id": 1, "text": "saat kaç", "expect": ["saat"], "reject": ["bilmiyorum"]},
    {"id": 2, "text": "şu an saat", "expect": ["saat"], "reject": ["bilmiyorum"]},

    {"id": 3, "text": "2+2", "expect": ["4"], "reject": ["bilmiyorum"]},
    {"id": 4, "text": "(3+8)*5", "expect": ["55"], "reject": ["hata"]},
    {"id": 5, "text": "2/0", "expect": ["böl"], "reject": ["4"]},

    # ===== B) SOCIAL =====
    {"id": 6, "text": "selam", "expect": ["merhaba", "selam"], "reject": ["saat"]},
    {"id": 7, "text": "naber", "expect": ["iyiyim", "nasılsın"], "reject": ["bilmiyorum"]},

    # ===== C) MEMORY =====
    {"id": 8, "text": "ben kimim", "expect": ["tanışmadık", "bilmiyorum"], "reject": ["burak"]},

    # ===== D) WEATHER =====
    {"id": 9, "text": "istanbul'da hava nasıl", "expect": ["istanbul", "°c"], "reject": ["bilmiyorum"]},
    {"id":10, "text": "kars hava durumu", "expect": ["kars", "°c"], "reject": ["istanbul"]},
    {"id":11, "text": "sancaktepe hava nasıl", "expect": ["istanbul", "°c"], "reject": ["bilmiyorum"]},

    # ===== E) FALLBACK / CHAT =====
    {"id":12, "text": "hayatın anlamı ne", "expect": ["anlam"], "reject": ["saat"]},
    {"id":13, "text": "python öğreniyorum", "expect": ["yardım", "öğren"], "reject": ["hava"]},
]


def main():
    print("=" * 50)
    print("JARVIS REGRESSION TEST")
    print("=" * 50)

    passed = 0
    for case in TESTS:
        time.sleep(0.3)
        if run_test(case):
            passed += 1

    print("=" * 50)
    print(f"SONUÇ: {passed}/{len(TESTS)} PASS")
    print("=" * 50)


if __name__ == "__main__":
    main()