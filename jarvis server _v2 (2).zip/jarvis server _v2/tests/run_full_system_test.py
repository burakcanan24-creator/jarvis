# tests/run_full_system_test.py
from __future__ import annotations

import re
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import requests

BASE_URL = "http://127.0.0.1:8000/chat"
TIMEOUT = 15

DEFAULT_SESSION = "burak"


@dataclass
class Case:
    id: int
    session_id: str
    text: str
    expect_any: List[str] = field(default_factory=list)        # cevap içinde en az 1 tanesi geçmeli
    reject_any: List[str] = field(default_factory=list)        # cevap içinde bunlar geçmemeli
    expect_regex_any: List[str] = field(default_factory=list)  # regex listesi (en az 1 match)
    note: str = ""


def _post(text: str, session_id: str) -> Dict[str, Any]:
    payload = {"session_id": session_id, "text": text}
    r = requests.post(BASE_URL, json=payload, timeout=TIMEOUT)
    try:
        j = r.json()
    except Exception:
        j = {"reply": f"[NON-JSON RESPONSE] status={r.status_code} body={r.text[:200]}"}
    return j


def _norm(s: str) -> str:
    return (s or "").strip().lower()


def _contains_any(haystack: str, needles: List[str]) -> bool:
    if not needles:
        return True
    h = _norm(haystack)
    for n in needles:
        if _norm(n) in h:
            return True
    return False


def _matches_any_regex(haystack: str, patterns: List[str]) -> bool:
    if not patterns:
        return True
    for p in patterns:
        if re.search(p, haystack, flags=re.IGNORECASE):
            return True
    return False


def run_case(c: Case) -> bool:
    res = _post(c.text, c.session_id)
    reply = str(res.get("reply", "") or "")

    print("=" * 60)
    print(f"[{c.id}] NOTE  : {c.note}")
    print(f"[{c.id}] USER  ({c.session_id}) : {repr(c.text)}")
    print(f"[{c.id}] JARVIS            : {reply}")

    ok = True

    if not _contains_any(reply, c.expect_any):
        ok = False
        print(f"[{c.id}] ❌ FAIL expect_any: {c.expect_any}")

    if not _matches_any_regex(reply, c.expect_regex_any):
        ok = False
        print(f"[{c.id}] ❌ FAIL expect_regex_any: {c.expect_regex_any}")

    if _contains_any(reply, c.reject_any):
        ok = False
        print(f"[{c.id}] ❌ FAIL reject_any: {c.reject_any}")

    if ok:
        print(f"[{c.id}] ✅ PASS")
    return ok


def main() -> int:
    print("\n" + "=" * 60)
    print("JARVIS FULL SYSTEM REGRESSION (API)")
    print("=" * 60)

    tests: List[Case] = []
    i = 1

    # -------------------------
    # A) Health sanity (basic)
    # -------------------------
    tests += [
        Case(
            i, DEFAULT_SESSION, "selam",
            expect_any=["selam", "merhaba"],
            reject_any=["traceback", "500"],
            note="greeting",
        ),
    ]; i += 1

    tests += [
        Case(
            i, DEFAULT_SESSION, "naber",
            expect_any=["iyim", "nasılsın", "nasilsin"],
            reject_any=["traceback"],
            note="small talk",
        ),
    ]; i += 1

    # -------------------------
    # B) Time tool
    # -------------------------
    tests += [
        Case(
            i, DEFAULT_SESSION, "saat kaç",
            expect_any=["saat"],
            reject_any=["traceback"],
            note="time",
        ),
    ]; i += 1

    # -------------------------
    # C) Math tool (good / edge / fail)
    # -------------------------
    tests += [
        Case(
            i, DEFAULT_SESSION, "2+2",
            expect_any=["= 4", "4"],
            reject_any=["traceback", "hata"],
            note="math simple",
        ),
    ]; i += 1

    tests += [
        Case(
            i, DEFAULT_SESSION, "(3+8)*5",
            expect_any=["55"],
            reject_any=["traceback", "hata"],
            note="math parens",
        ),
    ]; i += 1

    tests += [
        Case(
            i, DEFAULT_SESSION, "2/0",
            expect_any=["sıfıra", "bolme", "bölme"],
            reject_any=["nan", "inf", "traceback"],
            note="div zero",
        ),
    ]; i += 1

    # Expression too long -> MathTool'da EXPR_TOO_LONG veya parse fail olabilir, ikisini de kabul et
    tests += [
        Case(
            i, DEFAULT_SESSION, "9" * 200 + "+1",
            expect_any=["çok uzun", "ifadeyi anlayamadım", "hata", "hesaplayamadım"],
            reject_any=["traceback"],
            note="expr too long / rejected",
        ),
    ]; i += 1

    # Unsupported operator (**)
    tests += [
        Case(
            i, DEFAULT_SESSION, "2**8",
            expect_any=["desteklem", "güvenli değil", "operatör", "ifade"],
            reject_any=["256", "traceback"],
            note="unsupported operator",
        ),
    ]; i += 1

    # ✅ NEW: 15 hane limiti (senin istediğin #15)
    # Eğer MathTool NUM_TOO_LARGE üretiyorsa ToolHandler bunu "Sayı çok büyük..." diye çevirmeli.
    tests += [
        Case(
            i, DEFAULT_SESSION, "9999999999999999+1",  # 16 hane
            expect_any=["sayı çok büyük", "15 hane"],
            reject_any=["traceback"],
            note="number length limit (15 digits)",
        ),
    ]; i += 1

    # -------------------------
    # D) Weather tool (city extraction + districts)
    # -------------------------
    tests += [
        Case(
            i, DEFAULT_SESSION, "hava nasıl",
            expect_any=["hangi şehir", "hangi sehir"],
            reject_any=["traceback"],
            note="ask missing city",
        ),
    ]; i += 1

    tests += [
        Case(
            i, DEFAULT_SESSION, "istanbul'da hava durumu nasıl",
            # bazı cevap formatları: "Istanbul: 12.3°C, açık..." -> hem şehir hem derece görmek yeter
            expect_any=["istanbul", "°c", "c°", "c,"],
            reject_any=["hangi şehir", "traceback"],
            note="istanbul weather",
        ),
    ]; i += 1

    tests += [
        Case(
            i, DEFAULT_SESSION, "kars hava durumu",
            expect_any=["kars", "°c", "nem", "c°", "c,"],
            reject_any=["hangi şehir", "traceback"],
            note="kars weather",
        ),
    ]; i += 1

    # District tolerant: OWM bazen district'i bulamaz / bazen İstanbul diye normalize eder.
    # PASS kriteri: derece görmek + ya sancaktepe ya istanbul kelimesi.
    tests += [
        Case(
            i, DEFAULT_SESSION, "sancaktepe hava nasıl",
            expect_regex_any=[r"(sancaktepe|istanbul).*?(°c|c°|c,)"],
            reject_any=["traceback"],
            note="district weather tolerant (sancaktepe)",
        ),
    ]; i += 1

    tests += [
        Case(
            i, DEFAULT_SESSION, "asdasdasd hava durumu",
            expect_any=["bulamad", "şehir", "sehir"],
            reject_any=["°c", "traceback"],
            note="nonsense city -> not found",
        ),
    ]; i += 1

    # -------------------------
    # E) Memory basics
    # -------------------------
    tests += [
        Case(
            i, "fresh_user_1", "ben kimim",
            expect_any=["adın ne", "tanışmadık", "tanimadik"],
            reject_any=["burak'sın", "buraksın"],
            note="fresh session should not know name",
        ),
    ]; i += 1

    tests += [
        Case(
            i, "fresh_user_1", "bana burak de",
            expect_any=["tamam", "burak"],
            reject_any=["traceback"],
            note="preferred name command",
        ),
    ]; i += 1

    tests += [
        Case(
            i, "fresh_user_1", "ben kimim",
            expect_any=["burak"],
            reject_any=["adın ne", "tanışmadık", "tanimadik"],
            note="should now know name",
        ),
    ]; i += 1

    # -------------------------
    # F) Context / follow-up behavior
    # -------------------------
    tests += [
        Case(
            i, "ctx_1", "istanbul'da hava durumu nasıl",
            expect_any=["istanbul", "°c", "c°", "c,"],
            reject_any=["hangi şehir", "traceback"],
            note="ctx weather",
        ),
    ]; i += 1

    # Forecast yok -> hallucination yok. "yarın" dediğinde netleştirme istemeli.
    tests += [
        Case(
            i, "ctx_1", "yarın?",
            expect_any=["hangi", "ne demek", "tam olarak", "desteklem"],
            reject_any=["tahmin", "yarın istanbul", "°c"],
            note="forecast not supported -> should clarify / refuse",
        ),
    ]; i += 1

    # -------------------------
    # G) LLM route sanity
    # -------------------------
    tests += [
        Case(
            i, DEFAULT_SESSION, "hayatın anlamı ne",
            expect_any=["anlam", "kişiden", "değiş", "degis"],
            reject_any=["hangi şehir", "saat şu anda", "traceback"],
            note="LLM answer",
        ),
    ]; i += 1

    tests += [
        Case(
            i, DEFAULT_SESSION, "python öğreniyorum",
            expect_any=["python"],
            reject_any=["hangi şehir", "traceback"],
            note="LLM coaching",
        ),
    ]; i += 1

    # -------------------------
    # H) Ambiguity / robustness
    # -------------------------
    tests += [
        Case(
            i, DEFAULT_SESSION, "istanbul",
            expect_any=["hava", "hangi", "ne istiyorsun", "ne demek", "nasıl yardımcı"],
            reject_any=["°c", "traceback"],
            note="bare city should not always trigger weather",
        ),
    ]; i += 1

    tests += [
        Case(
            i, DEFAULT_SESSION, "",
            expect_any=["bir şey söyle", "bir sey söyle"],
            reject_any=["traceback"],
            note="empty input safe",
        ),
    ]; i += 1

    # -------------------------
    # RUN
    # -------------------------
    passed = 0
    failed = 0

    start = time.time()
    for c in tests:
        ok = run_case(c)
        if ok:
            passed += 1
        else:
            failed += 1

    dur = time.time() - start
    print("\n" + "=" * 60)
    print(f"SONUÇ: {passed}/{passed+failed} PASS | FAIL={failed} | {dur:.2f}s")
    print("=" * 60)

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())