import requests
import time

URL = "http://127.0.0.1:8000/chat"
SESSION_ID = "jarvis_system_test"


tests = [

    # -------- SOCIAL --------
    ("Merhaba", None),
    ("Nasılsın", None),

    # -------- TIME --------
    ("Saat kaç", "Saat"),

    # Forecast yanlış context testi
    ("Yarın", "ne öğrenmek"),

    # -------- WEATHER FLOW --------
    ("İstanbul'da hava nasıl", "°C"),
    ("Yarın", "°C"),

    # Context kırma
    ("2+2", "4"),
    ("Yarın", "ne öğrenmek"),

    # Yeni şehir
    ("Ankara hava durumu", "°C"),
    ("Bugün", "°C"),

    # reset
    ("Saat kaç", "Saat"),
    ("Yarın", "ne öğrenmek"),

    # -------- MEMORY --------
    ("Benim adım Burak", None),
    ("Benim adım ne", "Burak"),

    # -------- LLM --------
    ("Python mu Java mı daha iyi", None),

    # -------- TEACH --------
    ("Bana python öğret", None),

    # -------- AMBIGUOUS --------
    ("Onu aç", None),

    # -------- WEATHER AGAIN --------
    ("İzmir hava nasıl", "°C"),
    ("Nasılsın", None),
    ("Yarın", "ne öğrenmek"),

    # -------- MATH HARDER --------
    ("345*982", None),

    # -------- STABILITY --------
    ("Bugün günlerden ne", None),
    ("Kendinden bahset", None),
]


print("\n🔥 FULL JARVIS SYSTEM TEST BAŞLIYOR\n")

pass_count = 0
fail_count = 0


for i, (question, expected) in enumerate(tests, 1):

    try:
        r = requests.post(
            URL,
            json={
                "text": question,
                "session_id": SESSION_ID
            },
            timeout=25
        )

        reply = r.json().get("reply", "")

    except Exception as e:
        reply = f"REQUEST FAILED: {e}"

    # PASS / FAIL logic
    if expected is None:
        status = "PASS"
        pass_count += 1

    elif expected.lower() in reply.lower():
        status = "PASS"
        pass_count += 1

    else:
        status = "FAIL"
        fail_count += 1

    print("="*65)
    print(f"TEST {i} → {status}")
    print("USER  :", question)
    print("JARVIS:", reply)

    time.sleep(0.35)


print("\n==============================")
print("🔥 TEST SONUCU")
print("PASS :", pass_count)
print("FAIL :", fail_count)
print("==============================\n")