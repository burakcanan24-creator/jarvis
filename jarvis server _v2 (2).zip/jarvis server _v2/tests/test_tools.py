from core.tools.time_tool import TimeTool
from core.tools.math_tool import MathTool

def test_time():
    t = TimeTool()
    result = t.run({})
    print("TIME:", result)

def test_math():
    m = MathTool()
    result = m.run({"expression": "3+5*2"})
    print("MATH:", result)

if __name__ == "__main__":
    test_time()
    test_math()