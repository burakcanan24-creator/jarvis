from __future__ import annotations

from typing import Any, Dict, Optional
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class DecisionTrace:
    """
    Represents the last meaningful cognitive step of the agent.

    This is NOT memory.
    This is NOT logging.
    This is NOT reflection.

    This is a short-lived awareness snapshot:
    - What intent was chosen
    - Why it was chosen
    - With what confidence
    """

    intent: str
    confidence: float
    reason: str
    timestamp: str


class SessionTrace:
    """
    Session-scoped cognitive trace.

    Lives in RAM.
    Reset when session resets.
    NEVER written to disk.

    This is the SEED of consciousness.
    """

    def __init__(self) -> None:
        self._last_decision: Optional[DecisionTrace] = None

    def record_decision(
        self,
        intent: str,
        confidence: float,
        reason: str,
    ) -> None:
        self._last_decision = DecisionTrace(
            intent=intent,
            confidence=float(confidence),
            reason=str(reason),
            timestamp=datetime.utcnow().isoformat(),
        )

    def has_decision(self) -> bool:
        return self._last_decision is not None

    def get_last_decision(self) -> Optional[Dict[str, Any]]:
        if not self._last_decision:
            return None
        return asdict(self._last_decision)

    def clear(self) -> None:
        self._last_decision = None