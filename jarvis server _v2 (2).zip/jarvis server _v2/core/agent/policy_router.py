# core/agent/policy_router.py
from __future__ import annotations

from typing import Optional

from core.agent.session_store import SessionStore
from core.memory_manager import MemoryManager


class PolicyRouter:
    """
    Handles deterministic policy hooks early (e.g., forget/reset).
    """

    def handle_forget(self, sid: str, user_text: str, store: SessionStore, mem: MemoryManager) -> Optional[str]:
        if mem.should_forget(user_text):
            mem.forget_all()
            store.reset_session(sid)
            reply = "Tamam. Hafızamı sıfırladım."
            session = store.get_session(sid)
            store.append_turn(sid, session, user_text, reply, mem)
            return reply
        return None