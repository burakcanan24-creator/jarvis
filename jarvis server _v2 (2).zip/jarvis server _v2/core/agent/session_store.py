# core/agent/session_store.py
from __future__ import annotations

from typing import Optional, Any, Dict

from core.memory_manager import MemoryManager
from core.tone_detector import ConversationTone
from core.consciousness.session_trace import SessionTrace


class SessionStore:

    def __init__(self) -> None:
        self.sessions: dict[str, dict] = {}

    def get_session(self, sid: str) -> dict:
        if sid not in self.sessions:
            self.sessions[sid] = {
                "messages": [],
                "context": {"tone": ConversationTone.NEUTRAL.value},
                "trace": SessionTrace(),
                "last_weather_city": None,
            }
        else:
            s = self.sessions[sid]

            if not s.get("trace"):
                s["trace"] = SessionTrace()

            if not s.get("context"):
                s["context"] = {"tone": ConversationTone.NEUTRAL.value}

            if not s.get("messages"):
                s["messages"] = []

            if "last_weather_city" not in s:
                s["last_weather_city"] = None

        return self.sessions[sid]

    def reset_session(self, sid: str) -> None:
        self.sessions[sid] = {
            "messages": [],
            "context": {"tone": ConversationTone.NEUTRAL.value},
            "trace": SessionTrace(),
            "last_weather_city": None,
        }

    # -----------------------------
    # Conversation log
    # -----------------------------
    def append_turn(
        self,
        sid: str,
        session: dict,
        user_text: str,
        assistant_text: str,
        mem: MemoryManager,
    ) -> None:

        msgs = session.setdefault("messages", [])
        msgs.append({"role": "user", "content": user_text})
        msgs.append({"role": "assistant", "content": assistant_text})

        # 🔥 MEMORY CALL
        try:
            print(">>> MEMORY WRITE ATTEMPT")

            mem.save_conversation_turn(user_text, assistant_text)

            print(">>> MEMORY WRITE SUCCESS")

        except Exception as e:
            print("🚨 MEMORY WRITE FAILED:", e)
            raise   # artık yutma yok