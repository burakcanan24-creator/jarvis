# core/agent/query_router.py
from __future__ import annotations

from typing import Optional

from core.agent.session_store import SessionStore
from core.intent_detector import IntentDetector
from core.memory_manager import MemoryManager
from core.response_styler import ResponseStyler
from core.tone_detector import ConversationTone


class QueryRouter:
    """
    Memory/self/trivial queries.
    Memory & self & trivial can be lightly styled.
    """

    def __init__(self, intent_detector: IntentDetector, styler: ResponseStyler) -> None:
        self.intent_detector = intent_detector
        self.styler = styler

    def handle_memory_queries(
        self,
        sid: str,
        user_text: str,
        session: dict,
        store: SessionStore,
        mem: MemoryManager,
        tone: ConversationTone,
    ) -> Optional[str]:
        if self.intent_detector.is_who_am_i(user_text):
            name = mem.get_user_name()
            if name:
                reply = f"Sen {name}'sın."
            else:
                reply = "Henüz tanışmadık. Adın ne?"

            reply = self.styler.style(text=reply, tone=tone, kind="memory")
            store.append_turn(sid, session, user_text, reply, mem)
            return reply

        if self.intent_detector.is_last_question_query(user_text):
            last_msg = store.get_last_user_message(session)
            if last_msg:
                reply = f'Az önce şunu sormuştun: "{last_msg}"'
            else:
                reply = "Bu oturum yeni görünüyor."

            reply = self.styler.style(text=reply, tone=tone, kind="memory")
            store.append_turn(sid, session, user_text, reply, mem)
            return reply

        return None

    def handle_self_queries(
        self,
        sid: str,
        user_text: str,
        session: dict,
        store: SessionStore,
        mem: MemoryManager,
        tone: ConversationTone,
    ) -> Optional[str]:
        if self.intent_detector.is_self_identity_query(user_text):
            reply = (
                "Ben Jarvis. Burada sana yardımcı olmak için varım. "
                "Sohbet edebilirim, saat söyleyebilirim, basit matematik hesaplayabilirim "
                "ve konuşmalarımızdan bazı şeyleri hatırlayabilirim."
            )
            reply = self.styler.style(text=reply, tone=tone, kind="memory")
            store.append_turn(sid, session, user_text, reply, mem)
            return reply

        if self.intent_detector.is_capabilities_query(user_text):
            reply = (
                "Şu an şunları yapabiliyorum: sohbet, hafıza (isim gibi), matematik (+ - * / %), saat. "
                "Zamanla yeni yetenekler de ekleyeceğiz."
            )
            reply = self.styler.style(text=reply, tone=tone, kind="memory")
            store.append_turn(sid, session, user_text, reply, mem)
            return reply

        if self.intent_detector.is_assistant_mood_query(user_text):
            reply = "İyiyim 🙂 Sen nasılsın? Bugün sende ne var ne yok?"
            reply = self.styler.style(text=reply, tone=tone, kind="memory")
            store.append_turn(sid, session, user_text, reply, mem)
            return reply

        if self.intent_detector.is_relationship_query(user_text):
            name = mem.get_user_name()
            if name:
                reply = f"Evet, seni tanıyorum: {name}."
            else:
                reply = "Seni daha iyi tanımak isterim. Bana adını söyler misin?"

            reply = self.styler.style(text=reply, tone=tone, kind="memory")
            store.append_turn(sid, session, user_text, reply, mem)
            return reply

        return None

    def handle_trivial(
        self,
        sid: str,
        user_text: str,
        session: dict,
        store: SessionStore,
        mem: MemoryManager,
        tone: ConversationTone,
    ) -> Optional[str]:
        if not self.intent_detector.is_trivial(user_text):
            return None

        reply = self.intent_detector.handle_trivial(user_text)
        reply = self.styler.style(text=reply, tone=tone, kind="trivial")
        store.append_turn(sid, session, user_text, reply, mem)
        return reply