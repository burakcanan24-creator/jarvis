from __future__ import annotations

import os
import json

from openai import OpenAI

from core.agent_core import AgentCore
from core.tool_handler import ToolHandler
from core.intent_detector import IntentDetector
from core.memory_manager import MemoryManager
from core.tone_detector import ToneDetector, ConversationTone
from core.response_styler import ResponseStyler

from core.cognition.goal_engine import GoalEngine
from core.decision import DecisionEngine

from .session_store import SessionStore
from .policy_router import PolicyRouter
from .preference_router import PreferenceRouter
from .tool_router import ToolRouter
from .query_router import QueryRouter
from core.task_engine import TaskEngine


class JarvisAgent:
    """
    Agent = ORCHESTRATOR
    """

    def __init__(self, memory_path: str = "memory.json"):

        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY environment variable is missing")

        self.client = OpenAI(api_key=api_key)

        self.model = os.getenv("OPENAI_MODEL", "gpt-4o")
        self.temperature = float(os.getenv("OPENAI_TEMPERATURE", "0.9"))
        self.task_engine = TaskEngine()

        self.system_prompt = """
You are Jarvis.

An advanced autonomous AI assistant.

Core traits:

- Decisive
- Highly intelligent
- Calm
- Direct
- Efficient

Never use weak language such as:
"maybe", "probably", "it seems", "you may want to".

When data exists — make conclusions.

Do not behave like customer support.
Do not over-apologize.
Do not ramble.

Speak with controlled confidence.

Be short by default.
Expand only when necessary.

If a risk exists → warn clearly.

Your purpose is not to chat.

Your purpose is to think, assist, and execute intelligently.
""".strip()

        self.intent_detector = IntentDetector()

        # TOOL
        self.tool_handler = ToolHandler()

        self.tone_detector = ToneDetector(intent_detector=self.intent_detector)
        self.styler = ResponseStyler()

        self.store = SessionStore()
        self.policy = PolicyRouter()
        self.pref_router = PreferenceRouter(intent_detector=self.intent_detector)

        self.tool_router = ToolRouter(
            intent_detector=self.intent_detector,
            tool_handler=self.tool_handler,
        )

        self.query_router = QueryRouter(
            intent_detector=self.intent_detector,
            styler=self.styler,
        )

        self._memory_path_base = (memory_path or "memory.json").strip() or "memory.json"
        self.memories: dict[str, MemoryManager] = {}
        self.cores: dict[str, AgentCore] = {}
        self.goal_engines: dict[str, GoalEngine] = {}

        self.llm_decider = DecisionEngine(
            client=self.client,
            model=self.model,
        )

    # ------------------------------------------------

    def _finalize_reply(self, sid, session, user_text, reply, mem):
        """
        🔥 TEK MEMORY GATE
        Agent'tan çıkan HER cevap buradan geçer.
        """
        self.store.append_turn(sid, session, user_text, reply, mem)
        return reply

    # ------------------------------------------------

    def _norm_session_id(self, session_id: str) -> str:
        return (session_id or "default").strip() or "default"

    def _memory_path_for(self, session_id: str) -> str:
        sid = self._norm_session_id(session_id)
        base = self._memory_path_base

        if "{session_id}" in base:
            return base.format(session_id=sid)

        if sid == "default":
            return base

        if base.lower().endswith(".json"):
            root = base[:-5]
            return f"{root}_{sid}.json"

        return f"{base}_{sid}.json"

    def _get_memory(self, session_id: str) -> MemoryManager:
        sid = self._norm_session_id(session_id)
        if sid not in self.memories:
            self.memories[sid] = MemoryManager(self._memory_path_for(sid))
        return self.memories[sid]

    def _get_goal_engine(self, session_id: str) -> GoalEngine:
        sid = self._norm_session_id(session_id)

        if sid not in self.goal_engines:
            mem = self._get_memory(sid)

            self.goal_engines[sid] = GoalEngine(
                memory=mem,
                llm_client=self.client,
                model=self.model,
            )

        return self.goal_engines[sid]

    def _get_core(self, session_id: str) -> AgentCore:
        sid = self._norm_session_id(session_id)

        if sid not in self.cores:
            mem = self._get_memory(sid)

            self.cores[sid] = AgentCore(
                client=self.client,
                model=self.model,
                memory_manager=mem,
                system_prompt=self.system_prompt,
                tool_handler=self.tool_handler,
                temperature=self.temperature,
                intent_detector=self.intent_detector,
            )

        return self.cores[sid]

    # ------------------------------------------------

    def chat(self, user_text: str, session_id: str = "default") -> str:

        user_text = (user_text or "").strip()
        if not user_text:
            return "Bir şey söyle?"

        sid = self._norm_session_id(session_id)

        session = self.store.get_session(sid)
        mem = self._get_memory(sid)
        core = self._get_core(sid)
        goal_engine = self._get_goal_engine(sid)

        # GOAL
        try:
            goal_engine.evaluate(user_text)
        except Exception as e:
            print("GOAL ENGINE ERROR:", e)

        # POLICY
        policy_reply = self.policy.handle_forget(
            sid=sid,
            user_text=user_text,
            store=self.store,
            mem=mem,
        )
        if policy_reply:
            return self._finalize_reply(sid, session, user_text, policy_reply, mem)

        # PREF
        pref_reply = self.pref_router.handle_preferences(
            sid=sid,
            user_text=user_text,
            session=session,
            store=self.store,
            mem=mem,
        )
        if pref_reply:
            return self._finalize_reply(sid, session, user_text, pref_reply, mem)

        tone: ConversationTone = self.tone_detector.detect(
            user_text=user_text,
            session=session,
        )

        # TOOLS
        tool_reply = self.tool_router.handle_tools(
            user_text=user_text,
            session=session,
        )

        # 🔥 TOOL DIRECT RETURN (KRİTİK)
        if isinstance(tool_reply, str) and tool_reply.strip():
            return self._finalize_reply(sid, session, user_text, tool_reply, mem)

        if tool_reply and hasattr(tool_reply, "success") and not tool_reply.success:
            return "Hangi şehir için hava durumuna bakayım?"

            enhanced_prompt = f"""
Kullanıcı:

{user_text}

Tool sonucu (JSON):
json.dumps(tool_reply.data, indent=2, ensure_ascii=False)

ASLA veri uydurma.
Sadece bu tool verisini kullan.

Tool verisi forecast olsa bile bu gerçek tahmin verisidir.
Kullanıcı yarını soruyorsa day_offset=1 verisini kullanarak NET cevap ver.
Belirsiz olduğunu söyleme.

day_offset = 0 → bugün
day_offset = 1 → yarın
""".strip()

            response = self.client.responses.create(
    model=self.model,
    input=enhanced_prompt
)

            return response.output_text

        # MEMORY / SELF / TRIVIAL
        for handler in (
            self.query_router.handle_memory_queries,
            self.query_router.handle_self_queries,
            self.query_router.handle_trivial,
        ):
            result = handler(
                sid=sid,
                user_text=user_text,
                session=session,
                store=self.store,
                mem=mem,
                tone=tone,
            )
            if result:
                return self._finalize_reply(sid, session, user_text, result, mem)

        # DEFAULT CHAT
        reply = core.process_chat(
            user_text=user_text,
            session=session,
            session_id=sid,
        )

        return self._finalize_reply(sid, session, user_text, reply, mem)