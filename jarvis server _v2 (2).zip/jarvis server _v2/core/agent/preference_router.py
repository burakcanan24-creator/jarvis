# core/agent/preference_router.py
from __future__ import annotations

import re
from typing import Optional

from core.agent.session_store import SessionStore
from core.intent_detector import IntentDetector
from core.memory_manager import MemoryManager


class PreferenceRouter:
    """
    Applies preference extraction deterministically.
    If the message is ONLY a preference command, ACK and stop.
    """

    def __init__(self, intent_detector: IntentDetector) -> None:
        self.intent_detector = intent_detector

        self._pref_only_patterns = [
            re.compile(r"^\s*kısa\s+konuş\s*$", re.IGNORECASE),
            re.compile(r"^\s*kisa\s+konus\s*$", re.IGNORECASE),
            re.compile(r"^\s*kısa\s+cevap\s+ver\s*$", re.IGNORECASE),
            re.compile(r"^\s*kisa\s+cevap\s+ver\s*$", re.IGNORECASE),
            re.compile(r"^\s*kısa\s+cevapla\s*$", re.IGNORECASE),
            re.compile(r"^\s*kisa\s+cevapla\s*$", re.IGNORECASE),
            re.compile(r"^\s*ciddi\s+konuş\s*$", re.IGNORECASE),
            re.compile(r"^\s*resmi\s+konuş\s*$", re.IGNORECASE),
            re.compile(r"^\s*espri\s+yap\s*$", re.IGNORECASE),
            re.compile(r"^\s*şaka\s+yap\s*$", re.IGNORECASE),
        ]
        self._bana_de_re = re.compile(r"^\s*bana\s+([a-zçğıöşü]{2,})\s+de\s*$", re.IGNORECASE)

    def _is_preference_only(self, user_text: str) -> bool:
        t = (user_text or "").strip()
        if not t:
            return False

        # If it's tool/memory/self/trivial, it's not preference-only here.
        if self.intent_detector.is_time_query(t) or self.intent_detector.is_math_query(t) or self.intent_detector.is_weather_query(t):
            return False
        if self.intent_detector.is_who_am_i(t) or self.intent_detector.is_last_question_query(t):
            return False
        if (
            self.intent_detector.is_self_identity_query(t)
            or self.intent_detector.is_capabilities_query(t)
            or self.intent_detector.is_assistant_mood_query(t)
            or self.intent_detector.is_relationship_query(t)
        ):
            return False
        if self.intent_detector.is_trivial(t):
            return False

        if any(p.match(t) for p in self._pref_only_patterns):
            return True

        if self._bana_de_re.match(t):
            return True

        return False

    def handle_preferences(self, sid: str, user_text: str, session: dict, store: SessionStore, mem: MemoryManager) -> Optional[str]:
        prefs = mem.extract_preference(user_text)
        if not prefs:
            return None

        mem.apply_preference(prefs)
        session.setdefault("context", {})["last_pref_applied"] = True

        if not self._is_preference_only(user_text):
            return None

        preferred = prefs.get("preferred_name")
        if isinstance(preferred, str) and preferred.strip():
            reply = f"Tamam, sana {preferred.strip()} diyeceğim."
        else:
            reply = "Tamam. 👍"

        store.append_turn(sid, session, user_text, reply, mem)
        return reply