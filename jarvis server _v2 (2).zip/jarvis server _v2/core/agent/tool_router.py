from __future__ import annotations

import re
from typing import Optional, Dict, Any

from core.intent_detector import IntentDetector
from core.tool_handler import ToolHandler


class ToolRouter:

    def __init__(self, intent_detector: IntentDetector, tool_handler: ToolHandler) -> None:
        self.intent_detector = intent_detector
        self.tool_handler = tool_handler
        self._math_fallback_re = re.compile(r"[\d\.\,]+|[\+\-\*/%\(\)]")

    # ------------------------------------------------
    # SESSION
    # ------------------------------------------------

    def _get_last_city(self, session: Optional[Dict[str, Any]]) -> Optional[str]:
        return session.get("last_weather_city") if session else None

    def _get_last_intent(self, session: Optional[Dict[str, Any]]) -> Optional[str]:
        return session.get("last_intent") if session else None

    def _set_weather_context(self, session: Optional[Dict[str, Any]], city: str) -> None:
        if not session:
            return
        session["last_weather_city"] = city
        session["last_intent"] = "weather"

    def _clear_weather_context(self, session: Optional[Dict[str, Any]]) -> None:
        if not session:
            return
        session.pop("last_weather_city", None)

    def _set_intent(self, session: Optional[Dict[str, Any]], intent: str) -> None:
        if not session:
            return
        session["last_intent"] = intent

    # ------------------------------------------------
    # ROUTER
    # ------------------------------------------------

    def handle_tools(self, user_text: str, session: Optional[Dict[str, Any]] = None) -> Optional[str]:

        t = (user_text or "").strip()

        if not t:
            return None

        is_weather = self.intent_detector.is_weather_query(t)
        is_forecast = self.intent_detector.is_forecast_query(t)
        last_intent = self._get_last_intent(session)

        # ======================================================
        # WEATHER
        # ======================================================

        if is_weather:

            city = self.intent_detector.extract_city(t)

            if not city:
                return "Hangi şehir için hava durumunu istiyorsun?"

            day_offset = self.intent_detector.extract_day_offset(t)

            reply = self.tool_handler.get_weather(city, day_offset)

            # 🔥 CRITICAL
            self._set_weather_context(session, city)

            return reply

        # ======================================================
        # FORECAST FOLLOWUP
        # ======================================================

        if is_forecast:

            # 🔥 Context yoksa ASLA AI'ya bırakma
            if last_intent != "weather":
                return "Hangi şehir için hava durumunu öğrenmek istiyorsun?"

            city = self._get_last_city(session)

            if not city:
                return "Hangi şehir için hava durumunu istiyorsun?"

            day_offset = self.intent_detector.extract_day_offset(t)

            reply = self.tool_handler.get_weather(city, day_offset)

            # intent'i koru
            self._set_intent(session, "weather")

            return reply

        # ======================================================
        # TIME
        # ======================================================

        if self.intent_detector.is_time_query(t):

            self._clear_weather_context(session)
            self._set_intent(session, "time")

            return self.tool_handler.get_time()

        # ======================================================
        # MATH
        # ======================================================

        if self.intent_detector.is_math_query(t):

            self._clear_weather_context(session)
            self._set_intent(session, "math")

            expr = self.intent_detector.extract_math_expression(t)

            if not expr:
                tokens = self._math_fallback_re.findall(t)
                if tokens:
                    expr = "".join(tokens).replace(" ", "").replace(",", ".")
                    if not any(op in expr for op in "+-*/%"):
                        expr = None

            if not expr:
                return 'Hangi işlemi hesaplamamı istiyorsun? Örnek: "2+2" veya "3*5"'

            return self.tool_handler.calculate_expr(expr)

        # ======================================================
        # OTHER
        # ======================================================

        self._clear_weather_context(session)
        self._set_intent(session, "other")

        return None