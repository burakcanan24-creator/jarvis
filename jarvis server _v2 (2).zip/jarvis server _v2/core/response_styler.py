from __future__ import annotations

from core.tone_detector import ConversationTone


class ResponseStyler:
    """
    Styles deterministic replies (tool/memory/trivial) by tone.
    Safe: does not touch LLM responses yet.
    """

    def style(self, text: str, tone: ConversationTone, kind: str) -> str:
        s = (text or "").strip()
        if not s:
            return s

        # Neutral: keep as-is
        if tone == ConversationTone.NEUTRAL:
            return s

        # Serious: remove fluff
        if tone == ConversationTone.SERIOUS:
            return self._serious(s)

        # Friendly / Playful: add minimal friendliness without drifting
        if tone == ConversationTone.FRIENDLY:
            return self._friendly(s, kind)

        if tone == ConversationTone.PLAYFUL:
            return self._playful(s, kind)

        return s

    def _serious(self, s: str) -> str:
        # keep first line only if it's long
        lines = [ln.strip() for ln in s.splitlines() if ln.strip()]
        if not lines:
            return s
        # short and direct
        return lines[0]

    def _friendly(self, s: str, kind: str) -> str:
        # Keep it subtle
        if kind == "tool":
            return f"{s} 🙂"
        if kind == "memory":
            return f"{s} 🙂"
        if kind == "trivial":
            return s
        return s

    def _playful(self, s: str, kind: str) -> str:
        if kind == "tool":
            # light playful wrapper, no extra questions
            return f"{s} 😄"
        if kind == "memory":
            return f"{s} 😄"
        if kind == "trivial":
            return s
        return s