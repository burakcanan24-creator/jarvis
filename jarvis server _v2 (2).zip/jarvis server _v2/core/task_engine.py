from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime


class TaskEngine:

    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.scheduler.start()

    def schedule_weather_check(self, city: str, session_id: str):
        """
        Her sabah 08:00'de hava durumunu kontrol eder.
        """

        self.scheduler.add_job(
            func=self._weather_job,
            trigger="cron",
            hour=8,
            minute=0,
            args=[city, session_id],
            id=f"weather_{session_id}",
            replace_existing=True
        )

        print(f">>> Weather task scheduled for {city} ({session_id})")

    def _weather_job(self, city: str, session_id: str):
        """
        Burayı birazdan ToolHandler'a bağlayacağız.
        Şimdilik sadece çalıştığını görelim.
        """

        print(f">>> Checking weather for {city} at {datetime.now()}")