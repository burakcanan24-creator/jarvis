# core/tools/registry.py
from __future__ import annotations

from typing import Dict, Any, Callable

from core.pipeline.contracts import ToolPlan, ToolResult, ToolName


FORBIDDEN_DATA_KEYS = {"text", "reply", "memory_set", "final_response"}


class ToolRegistry:
    """
    ToolRegistry görevi:
    - ToolPlan -> ilgili tool'u çalıştır -> ToolResult döndür
    - Tool sözleşmelerini enforce eder (fail-fast)
    - Tool türleri:
        1) callable(args) -> ToolResult
        2) obj.run(args) -> ToolResult
        3) obj.execute(args) -> ToolResult
    """

    def __init__(self, tools: Dict[ToolName, Any] | None = None, strict: bool = True):
        self._tools: Dict[ToolName, Any] = tools or {}
        self.strict = strict

    def register(self, name: ToolName, tool: Any) -> None:
        self._tools[name] = tool

    def execute(self, plan: ToolPlan) -> ToolResult:
        tool = self._tools.get(plan.tool_name)
        if not tool:
            return ToolResult(tool_name=plan.tool_name, success=False, data={}, error="Tool not found")

        args = plan.args or {}

        # 1) callable tool
        if callable(tool):
            result = tool(args)
            self._enforce_tool_contract(plan.tool_name, result)
            return result

        # 2) object tool: .run(args)
        if hasattr(tool, "run") and callable(getattr(tool, "run")):
            result = tool.run(args)
            self._enforce_tool_contract(plan.tool_name, result)
            return result

        # 3) object tool: .execute(args)
        if hasattr(tool, "execute") and callable(getattr(tool, "execute")):
            result = tool.execute(args)
            self._enforce_tool_contract(plan.tool_name, result)
            return result

        self._fail(f"Tool '{plan.tool_name}' is not callable and has no run/execute method")
        # strict=False durumunda buraya düşerse güvenli fallback:
        return ToolResult(tool_name=plan.tool_name, success=False, data={}, error="Tool interface invalid")

    def _enforce_tool_contract(self, tool_name: ToolName, result: Any) -> None:
        # 1) Tip kontrolü
        if not isinstance(result, ToolResult):
            self._fail(f"Tool '{tool_name}' must return ToolResult, got {type(result)}")

        # 2) tool_name tutarlılığı
        if result.tool_name != tool_name:
            self._fail(f"ToolResult.tool_name mismatch: expected {tool_name}, got {result.tool_name}")

        # 3) data dict olmalı
        data = result.data or {}
        if not isinstance(data, dict):
            self._fail(f"ToolResult.data must be dict, got {type(data)}")

        # 4) data içinde yasak anahtarlar yok
        bad = FORBIDDEN_DATA_KEYS.intersection(set(data.keys()))
        if bad:
            self._fail(f"Tool '{tool_name}' returned forbidden data keys: {sorted(bad)}")

        # 5) success=False ise error zorunlu
        if result.success is False and not result.error:
            self._fail(f"Tool '{tool_name}' returned success=False but error is empty")

    def _fail(self, msg: str) -> None:
        if self.strict:
            raise TypeError(msg)
        print(f"[WARN] {msg}")
