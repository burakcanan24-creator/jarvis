from __future__ import annotations
from datetime import datetime
from core.pipeline.contracts import ToolResult, ToolName

class TimeTool:
    def run(self, args: dict) -> ToolResult:
        tz = (args or {}).get("timezone")

        try:
            if tz:
                from zoneinfo import ZoneInfo
                now = datetime.now(ZoneInfo(tz))
            else:
                now = datetime.now()
        except Exception:
            now = datetime.now()

        return ToolResult(
            tool_name=ToolName.TIME,
            success=True,
            data={"time": now.strftime("%H:%M")},
            error=None,
        )