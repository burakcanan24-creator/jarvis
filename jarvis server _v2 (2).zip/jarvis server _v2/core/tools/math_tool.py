# core/tools/math_tool.py
from __future__ import annotations

import ast
import re

from core.pipeline.contracts import ToolResult, ToolName


MAX_EXPR_LEN = 128  # DoS koruması: aşırı uzun ifadeyi reddet

# 15 hane limiti: expression içindeki her sayı token'ı en fazla 15 hane olabilir
MAX_NUM_DIGITS = 15
_NUM_RE = re.compile(r"\d+")


class MathError:
    # Input / validation
    MISSING_EXPRESSION = "ERR_MATH_MISSING_EXPRESSION"
    EMPTY_EXPRESSION = "ERR_MATH_EMPTY_EXPRESSION"
    EXPR_TOO_LONG = "ERR_MATH_EXPR_TOO_LONG"
    NUM_TOO_LARGE = "ERR_MATH_NUM_TOO_LARGE"  # NEW: 15 hane limiti

    # Evaluation
    UNSUPPORTED_OPERATOR = "ERR_MATH_UNSUPPORTED_OPERATOR"
    UNSUPPORTED_ELEMENT = "ERR_MATH_UNSUPPORTED_ELEMENT"
    ONLY_NUMBERS = "ERR_MATH_ONLY_NUMBERS"
    DIV_ZERO = "ERR_MATH_DIV_ZERO"
    NON_NUMERIC_RESULT = "ERR_MATH_NON_NUMERIC_RESULT"
    PARSE_ERROR = "ERR_MATH_PARSE_ERROR"


class _SafeMathEvaluator(ast.NodeVisitor):
    """
    Güvenli aritmetik evaluator:
    - İzinli: sayı, + - * / %, parantez, unary +/-
    - Yasak: isimler, çağrılar, attribute, pow(**), bitwise, comparisons, bool ops...
    """

    def visit_Expression(self, node: ast.Expression):
        return self.visit(node.body)

    def visit_BinOp(self, node: ast.BinOp):
        left = self.visit(node.left)
        right = self.visit(node.right)

        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            return left / right
        if isinstance(node.op, ast.Mod):
            return left % right

        raise ValueError(MathError.UNSUPPORTED_OPERATOR)

    def visit_UnaryOp(self, node: ast.UnaryOp):
        val = self.visit(node.operand)
        if isinstance(node.op, ast.UAdd):
            return +val
        if isinstance(node.op, ast.USub):
            return -val
        raise ValueError(MathError.UNSUPPORTED_OPERATOR)

    def visit_Constant(self, node: ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValueError(MathError.ONLY_NUMBERS)

    # Python <3.8 uyumu
    def visit_Num(self, node: ast.Num):  # type: ignore
        if isinstance(node.n, (int, float)):
            return node.n
        raise ValueError(MathError.ONLY_NUMBERS)

    def generic_visit(self, node):
        # Burada detay stringi üretmiyoruz; ToolHandler sadece koda göre konuşacak.
        raise ValueError(MathError.UNSUPPORTED_ELEMENT)


class MathTool:
    def run(self, args: dict) -> ToolResult:
        expr = (args or {}).get("expression")

        if not expr or not isinstance(expr, str):
            return ToolResult(
                tool_name=ToolName.MATH,
                success=False,
                data={},
                error=MathError.MISSING_EXPRESSION,
            )

        expr = expr.strip()
        if not expr:
            return ToolResult(
                tool_name=ToolName.MATH,
                success=False,
                data={},
                error=MathError.EMPTY_EXPRESSION,
            )

        if len(expr) > MAX_EXPR_LEN:
            return ToolResult(
                tool_name=ToolName.MATH,
                success=False,
                data={},
                error=MathError.EXPR_TOO_LONG,
            )

        # NEW: 15 hane limit kontrolü (her sayı token'ı için)
        nums = _NUM_RE.findall(expr)
        if any(len(n) > MAX_NUM_DIGITS for n in nums):
            return ToolResult(
                tool_name=ToolName.MATH,
                success=False,
                data={},
                error=MathError.NUM_TOO_LARGE,
            )

        try:
            tree = ast.parse(expr, mode="eval")
            evaluator = _SafeMathEvaluator()
            result = evaluator.visit(tree)
        except ZeroDivisionError:
            return ToolResult(
                tool_name=ToolName.MATH,
                success=False,
                data={},
                error=MathError.DIV_ZERO,
            )
        except Exception as e:
            # Eğer evaluator kendi kodlarımızı fırlattıysa onu kullan
            msg = str(e)
            known = {
                MathError.UNSUPPORTED_OPERATOR,
                MathError.UNSUPPORTED_ELEMENT,
                MathError.ONLY_NUMBERS,
                MathError.NUM_TOO_LARGE,  # NEW: yakalamaya dahil
            }
            code = msg if msg in known else MathError.PARSE_ERROR

            return ToolResult(
                tool_name=ToolName.MATH,
                success=False,
                data={},
                error=code,
            )

        if not isinstance(result, (int, float)):
            return ToolResult(
                tool_name=ToolName.MATH,
                success=False,
                data={},
                error=MathError.NON_NUMERIC_RESULT,
            )

        return ToolResult(
            tool_name=ToolName.MATH,
            success=True,
            data={"result": result},
            error=None,
        )