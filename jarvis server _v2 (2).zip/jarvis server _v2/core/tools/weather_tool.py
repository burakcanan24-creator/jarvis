from __future__ import annotations

import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from dotenv import load_dotenv

from core.pipeline.contracts import ToolResult, ToolName


class WeatherError:
    MISSING_CITY = "ERR_WEATHER_MISSING_CITY"
    FETCH_FAILED = "ERR_WEATHER_FETCH_FAILED"
    API_KEY_MISSING = "ERR_WEATHER_API_KEY_MISSING"
    PARSE_ERROR = "ERR_WEATHER_PARSE_ERROR"
    CITY_NOT_FOUND = "ERR_WEATHER_CITY_NOT_FOUND"
    FORECAST_NOT_AVAILABLE = "ERR_WEATHER_FORECAST_NOT_AVAILABLE"


class WeatherTool:
    """
    PRODUCTION SAFE WEATHER TOOL

    Rules:
    ✔ Tool NEVER prints
    ✔ Tool NEVER crashes
    ✔ Tool ONLY returns ToolResult
    ✔ dotenv loaded once with absolute path
    ✔ API key cached
    """

    def __init__(self) -> None:
        self._api_key: Optional[str] = None
        self._dotenv_loaded: bool = False

    # ------------------------------------------------
    # DOTENV
    # ------------------------------------------------

    def _load_env_once(self) -> None:
        if self._dotenv_loaded:
            return

        self._dotenv_loaded = True

        try:
            root = Path(__file__).resolve().parents[2]
            env_path = root / ".env"

            if env_path.exists():
                load_dotenv(env_path)
        except Exception:
            # tool ASLA patlamaz
            pass

    # ------------------------------------------------
    # API KEY
    # ------------------------------------------------

    def _get_api_key(self) -> str:
        if self._api_key:
            return self._api_key

        self._load_env_once()

        key = (os.getenv("WEATHER_API_KEY") or "").strip()
        self._api_key = key
        return key

    # ------------------------------------------------
    # ENTRY
    # ------------------------------------------------

    def run(self, args: dict) -> ToolResult:
        args = args or {}

        api_key = self._get_api_key()
        if not api_key:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.API_KEY_MISSING,
            )

        city = (args.get("city") or "").strip()
        mode = str(args.get("mode") or "current").strip().lower()
        day_offset_raw = args.get("day_offset", 1)

        if not city:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.MISSING_CITY,
            )

        if mode == "forecast":
            try:
                day_offset = int(day_offset_raw)
            except Exception:
                day_offset = 1
            return self._run_forecast(city, day_offset, api_key)

        return self._run_current(city, api_key)

    # ------------------------------------------------
    # CURRENT WEATHER
    # ------------------------------------------------

    def _run_current(self, city: str, api_key: str) -> ToolResult:
        try:
            resp = requests.get(
                "https://api.openweathermap.org/data/2.5/weather",
                params={
                    "q": city,
                    "appid": api_key,
                    "units": "metric",
                    "lang": "tr",
                },
                timeout=8,
            )
        except Exception:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.FETCH_FAILED,
            )

        if resp.status_code == 404:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.CITY_NOT_FOUND,
            )

        if resp.status_code != 200:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.FETCH_FAILED,
            )

        try:
            data: Dict[str, Any] = resp.json()

            main = data["main"]
            weather = (data.get("weather") or [{}])[0]

            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=True,
                data={
                    "mode": "current",
                    "city": data.get("name", city),
                    "temp_c": round(float(main["temp"]), 1),
                    "humidity": int(main["humidity"]),
                    "description": weather.get("description", "bilinmiyor"),
                },
                error=None,
            )
        except Exception:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.PARSE_ERROR,
            )

    # ------------------------------------------------
    # FORECAST
    # ------------------------------------------------

    def _run_forecast(self, city: str, day_offset: int, api_key: str) -> ToolResult:
        try:
            resp = requests.get(
                "https://api.openweathermap.org/data/2.5/forecast",
                params={
                    "q": city,
                    "appid": api_key,
                    "units": "metric",
                    "lang": "tr",
                },
                timeout=8,
            )
        except Exception:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.FETCH_FAILED,
            )

        if resp.status_code == 404:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.CITY_NOT_FOUND,
            )

        if resp.status_code != 200:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.FETCH_FAILED,
            )

        try:
            data: Dict[str, Any] = resp.json()
            items = data.get("list") or []

            if not items:
                return ToolResult(
                    tool_name=ToolName.WEATHER,
                    success=False,
                    data={},
                    error=WeatherError.FORECAST_NOT_AVAILABLE,
                )

            target_date = datetime.utcnow().date() + timedelta(days=day_offset)

            best = None
            best_delta = None

            for it in items:
                dt_txt = it.get("dt_txt")
                if not isinstance(dt_txt, str):
                    continue

                dt = datetime.strptime(dt_txt, "%Y-%m-%d %H:%M:%S")
                if dt.date() != target_date:
                    continue

                delta = abs(dt.hour - 12)
                if best_delta is None or delta < best_delta:
                    best_delta = delta
                    best = it

            if not best:
                return ToolResult(
                    tool_name=ToolName.WEATHER,
                    success=False,
                    data={},
                    error=WeatherError.FORECAST_NOT_AVAILABLE,
                )

            main = best["main"]
            weather = (best.get("weather") or [{}])[0]

            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=True,
                data={
                    "mode": "forecast",
                    "city": (data.get("city") or {}).get("name", city),
                    "temp_c": round(float(main["temp"]), 1),
                    "humidity": int(main["humidity"]),
                    "description": weather.get("description", "bilinmiyor"),
                    "day_offset": day_offset,
                },
                error=None,
            )
        except Exception:
            return ToolResult(
                tool_name=ToolName.WEATHER,
                success=False,
                data={},
                error=WeatherError.PARSE_ERROR,
            )