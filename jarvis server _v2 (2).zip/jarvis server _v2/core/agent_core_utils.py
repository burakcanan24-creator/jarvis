# core/agent_core_utils.py
from __future__ import annotations

from typing import Dict, List, Optional
from core.agent_core_constants import TRIVIAL_SET


def is_trivial(text: str) -> bool:
    t = (text or "").strip().lower()
    if not t:
        return True
    return t in TRIVIAL_SET


def trim_messages(
    messages: List[Dict[str, str]],
    max_messages: int,
    keep_last: int,
) -> List[Dict[str, str]]:
    if len(messages) <= max_messages:
        return messages

    system_msg = messages[0] if messages and messages[0].get("role") == "system" else None
    trimmed = messages[-keep_last:]

    if system_msg and (not trimmed or trimmed[0] is not system_msg):
        return [system_msg] + trimmed

    return trimmed


def build_memory_note(memory, user_text: str) -> Optional[str]:
    try:
        relevant = memory.get_relevant_memories(user_text)
    except Exception:
        relevant = []

    if not relevant:
        return None

    lines = ["Bellek:"]
    for item in relevant[:3]:
        lines.append(f"- {item}")
    return "\n".join(lines)