from typing import Dict


class SignalDetector:
    """
    Kullanıcı mesajında PLAN / NİYET var mı?
    Planner sadece sinyal varsa çalışır.
    """

    KEYWORDS = [
        "yarın",
        "gideceğim",
        "gideceğiz",
        "uçuş",
        "toplantı",
        "randevu",
        "spor",
        "koşu",
        "seyahat",
        "tatil",
    ]

    def detect(self, text: str) -> Dict:

        t = (text or "").lower()

        for k in self.KEYWORDS:
            if k in t:
                return {
                    "signal": True,
                    "type": "plan_hint",
                    "confidence": 0.6,
                }

        return {
            "signal": False
        }