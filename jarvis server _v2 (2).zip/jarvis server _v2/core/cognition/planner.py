from typing import Dict, Optional


class Planner:
    """
    Signal varsa basit plan üretir.
    Henüz AI planning değil.
    Ama agent davranışının başlangıcı.
    """

    def create_plan(self, signal: Dict) -> Optional[Dict]:

        if not signal.get("signal"):
            return None

        return {
            "goal": "assist_user_plan",
            "actions": [
                {
                    "type": "check_weather"
                }
            ]
        }