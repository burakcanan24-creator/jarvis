from __future__ import annotations

import json
import re
from typing import Optional, Dict, Any

from openai import OpenAI


class GoalEngine:
    """
    Jarvis'in UZUN VADELİ BEYNİ.

    DecisionEngine KULLANMAZ.
    Direkt LLM classifier gibi çalışır.
    """

    def __init__(self, memory, llm_client: OpenAI, model: str = "gpt-4.1-mini"):
        self.memory = memory
        self.client = llm_client
        self.model = model

        self._signal_re = re.compile(
            r"\b("
            r"başlayacağım|başlıyorum|artık|karar\s+verdim|hedefim|"
            r"düzenli|her\s+gün|bundan\s+sonra|alışkanlık|rutine"
            r")\b",
            re.IGNORECASE,
        )

    # ------------------------------------------------

    def evaluate(self, user_text: str) -> Optional[Dict[str, Any]]:

        if not self._prefilter(user_text):
            return None

        decision = self._llm_goal_check(user_text)

        if not decision:
            print("[GOAL] LLM returned nothing")
            return None

        goal = decision.get("goal")
        confidence = self._clamp_confidence(decision.get("confidence", 0))

        if not goal or goal == "none" or confidence < 0.75:
            print(f"[GOAL FILTERED] goal={goal} confidence={confidence}")
            return None

        print(f"[GOAL DETECTED] {goal} ({confidence})")

        try:
            lt = self.memory.memory.setdefault("long_term", {})
            goals = lt.setdefault("goals", [])

            if goal not in goals:
                goals.append(goal)
                self.memory.save()
                print(f"[GOAL SAVED] {goal}")
            else:
                print(f"[GOAL EXISTS] {goal}")

        except Exception as e:
            print("[GOAL MEMORY ERROR]", e)

        return {
            "goal_detected": True,
            "goal": goal,
            "confidence": confidence
        }

    # ------------------------------------------------

    def _prefilter(self, text: str) -> bool:
        if not text:
            return False

        return bool(self._signal_re.search(text))

    # ------------------------------------------------

    def _llm_goal_check(self, text: str) -> Optional[Dict[str, Any]]:

        prompt = f"""
You are a behavioral classifier.

Detect whether the user is starting a LONG TERM life change.

RETURN STRICT JSON ONLY:

{{
 "goal": "health | productivity | learning | finance | social | none",
 "confidence": 0.0-1.0
}}

User message:
{text}
"""

        try:

            print("LLM GOAL CHECK CALLED")

            response = self.client.chat.completions.create(
                model=self.model,
                temperature=0,
                messages=[
                    {"role": "system", "content": prompt},
                ],
            )

            content = response.choices[0].message.content.strip()

            print("LLM RAW:", content)

            decision = self._extract_json(content)

            print("LLM PARSED:", decision)

            return decision

        except Exception as e:
            print("[GOAL LLM ERROR]", e)
            return None

    # ------------------------------------------------

    def _extract_json(self, text: str) -> Optional[Dict[str, Any]]:
        if not text:
            return None

        try:
            return json.loads(text)
        except Exception:
            pass

        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except Exception:
                return None

        return None

    # ------------------------------------------------

    def _clamp_confidence(self, value) -> float:
        try:
            v = float(value)
            return max(0.0, min(1.0, v))
        except Exception:
            return 0.0