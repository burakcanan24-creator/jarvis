from __future__ import annotations

from typing import Optional, Dict, Any


class PlannerEngine:
    """
    Jarvis Planner Brain v2

    Upgrade:
    - Keyword + LLM hybrid decision
    - Weather ihtiyacını model de anlayabiliyor
    - False negative ciddi azaltıldı
    """

    def __init__(self, tool_handler, memory, client=None, model="gpt-4o-mini"):
        self.tool_handler = tool_handler
        self.memory = memory
        self.client = client
        self.model = model

    # ------------------------------------------------

    def evaluate(self, user_text: str) -> Optional[Dict[str, Any]]:

        t = (user_text or "").lower()

        if not self._has_plan_signal(t):
            return None

        context: Dict[str, Any] = {
            "planner_active": True,
            "signals": [],
            "tool_data": [],
            "risk_detected": False,
        }

        # 🔥 HYBRID WEATHER DECISION
        weather_needed = (
            self._should_check_weather(t)
            or self._llm_weather_decision(t)
        )

        if not weather_needed:
            return context

        # ŞEHİR
        try:
            city = self.memory.get("last_weather_city") or "Istanbul"
        except Exception:
            city = "Istanbul"

        # GÜN
        day_offset = 1 if "yarın" in t else 0

        # WEATHER TOOL
        try:
            weather = self.tool_handler.get_weather(
                city=city,
                day_offset=day_offset
            )

            context["signals"].append("weather_check")
            context["tool_data"].append(weather)

        except Exception:
            return context

        # RISK
        risk_words = [
            "yağmur",
            "fırtına",
            "kar",
            "sağanak",
            "dolu",
            "buz",
        ]

        if isinstance(weather, str) and any(r in weather.lower() for r in risk_words):
            context["risk_detected"] = True

        # GOOD WEATHER
        good_words = [
            "güneş",
            "açık",
            "ılık",
        ]

        if isinstance(weather, str) and any(g in weather.lower() for g in good_words):
            context["signals"].append("good_weather")

        return context

    # ------------------------------------------------
    # 🔥 LLM WEATHER DECISION (MINI BRAIN)
    # ------------------------------------------------

    def _llm_weather_decision(self, text: str) -> bool:

        if not self.client:
            return False

        prompt = f"""
User message:
{text}

Is weather information REQUIRED to give a smart recommendation?

Answer ONLY with:
YES
or
NO
"""

        try:

            res = self.client.chat.completions.create(
                model=self.model,
                temperature=0,
                messages=[
                    {"role": "system", "content": "You are a decision engine."},
                    {"role": "user", "content": prompt}
                ],
            )

            answer = res.choices[0].message.content.strip().upper()

            return "YES" in answer

        except Exception:
            return False

    # ------------------------------------------------

    def _has_plan_signal(self, text: str) -> bool:

        keywords = [
            "yarın",
            "gideceğim",
            "gidecegim",
            "plan",
            "seyahat",
            "uçuş",
            "toplantı",
            "randevu",
            "koşu",
            "yürüyüş",
            "spor",
            "gez",
            "piknik",
            "dışarı",
            "disari",
            "araba",
            "yıkayacağım",
            "yikayacagim",
            "temizlik",
        ]

        return any(k in text for k in keywords)

    # ------------------------------------------------

    def _should_check_weather(self, text: str) -> bool:

        time_words = [
            "yarın",
            "bugün",
            "hafta sonu",
            "akşam",
            "aksam",
            "sabah",
        ]

        weather_sensitive = [
            "koşu",
            "yürüyüş",
            "piknik",
            "kamp",
            "bisiklet",
            "araba yık",
            "araba yıka",
            "araba yıkay",
            "temizlik",
            "dışarı",
            "disari",
            "bahçe",
            "bahce",
            "mangal",
            "balık",
            "balik",
        ]

        has_time = any(w in text for w in time_words)
        weather_related = any(w in text for w in weather_sensitive)

        return has_time and weather_related