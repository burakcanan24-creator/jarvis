# core/pipeline/contracts.py
from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional, Literal, Union
from pydantic import BaseModel, Field


# =========================================================
# 1) INPUT / REQUEST
# =========================================================

class Channel(str, Enum):
    CLI = "cli"
    HTTP = "http"
    ANDROID = "android"
    UNKNOWN = "unknown"


class UserRequest(BaseModel):
    """
    Sisteme giren tek şey budur: ham metin + metadata.
    """
    text: str = Field(..., min_length=1)
    channel: Channel = Channel.UNKNOWN
    user_id: str = "default"
    session_id: str = "default"
    locale: str = "tr-TR"
    timestamp_ms: int = 0  # dışarıdan verilmezse orchestrator doldurabilir


# =========================================================
# 2) ANALYSIS (Analyzer output)
# =========================================================

class Intent(str, Enum):
    CHAT = "chat"
    ASK_TIME = "ask_time"
    CALCULATE = "calculate"

    # ✅ NEW: Weather intent
    ASK_WEATHER = "ask_weather"

    CONTROL_DEVICE = "control_device"
    MEMORY_SET = "memory_set"
    MEMORY_GET = "memory_get"

    # ✅ Teaching / Learning
    LEARN = "learn"

    # ✅ Scope definition (V1 capability list / "ilk sürümde şunlar olsun")
    DEFINE_SCOPE = "define_scope"

    UNKNOWN = "unknown"


class Analysis(BaseModel):
    """
    Analyzer asla tool çağırmaz, asla cevap üretmez.
    Sadece: "ne istiyor?" sorusunu yapılandırır.
    """
    intent: Intent = Intent.UNKNOWN
    confidence: float = Field(0.0, ge=0.0, le=1.0)

    # Entities/slots: cihaz, oda, eylem, sayı ifadesi vs.
    entities: Dict[str, Any] = Field(default_factory=dict)

    # Debug amaçlı iz bırakmak serbest (kullanıcıya gösterilmez)
    debug: Dict[str, Any] = Field(default_factory=dict)


# =========================================================
# 3) PLAN (Planner output)
# =========================================================

class ToolName(str, Enum):
    TIME = "time"
    MATH = "math"

    # ✅ NEW: Weather tool
    WEATHER = "weather"

    # ileride: SYSTEM, WEB, LIGHT, ...
    UNKNOWN = "unknown"


class ToolPlan(BaseModel):
    type: Literal["tool"] = "tool"
    tool_name: ToolName
    args: Dict[str, Any] = Field(default_factory=dict)


class AnswerPlan(BaseModel):
    """
    Tool gerekmiyorsa direkt cevap planı.
    """
    type: Literal["answer"] = "answer"
    style: Literal["chat", "short", "strict"] = "chat"
    content_hint: Optional[str] = None  # responder'a ipucu (zorunlu değil)
    meta: Dict[str, Any] = Field(default_factory=dict)  # ✅ orchestrator/responder payload


class ClarifyPlan(BaseModel):
    """
    Eksik bilgi varsa soru sor.
    """
    type: Literal["clarify"] = "clarify"
    question: str
    # Planner isterse seçenekler sunabilir
    options: List[str] = Field(default_factory=list)


Plan = Union[ToolPlan, AnswerPlan, ClarifyPlan]


# =========================================================
# 4) TOOL RESULT (Tool output)
# =========================================================

class ToolResult(BaseModel):
    """
    Tool asla kullanıcıya cümle yazmaz.
    Sadece veri döndürür.
    """
    tool_name: ToolName
    success: bool = True
    data: Dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = None


# =========================================================
# 5) FINAL RESPONSE (Responder output)
# =========================================================

class Reply(BaseModel):
    """
    Kullanıcıya giden tek şey.
    """
    text: str
    meta: Dict[str, Any] = Field(default_factory=dict)


# =========================================================
# 6) PIPELINE TRACE (Orchestrator internal)
# =========================================================

class PipelineTrace(BaseModel):
    """
    Debug / test için: adımların hepsi burada izlenir.
    """
    request: UserRequest
    analysis: Optional[Analysis] = None
    plan: Optional[Plan] = None
    tool_result: Optional[ToolResult] = None
    reply: Optional[Reply] = None


# =========================================================
# HARD RULES (doc-only, enforcement orchestrator/tests)
# =========================================================
# KURAL 1: Analyzer -> sadece Analysis döndürür. Tool/Reply yok.
# KURAL 2: Planner  -> sadece Plan döndürür. Tool çağırmaz.
# KURAL 3: Tool     -> sadece ToolResult döndürür. Reply üretmez.
# KURAL 4: Responder-> sadece Reply döndürür. Tool çağırmaz.
# KURAL 5: Memory   -> sadece store.py üzerinden okunur/yazılır.