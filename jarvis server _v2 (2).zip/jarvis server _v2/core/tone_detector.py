from __future__ import annotations

import enum
import re
from typing import Any


class ConversationTone(enum.Enum):
    NEUTRAL = "neutral"
    FRIENDLY = "friendly"
    PLAYFUL = "playful"
    SERIOUS = "serious"


class ToneDetector:
    """
    Deterministic tone detection (safe).
    - No LLM usage.
    - Uses keywords + simple context persistence in session["context"]["tone"].
    """

    def __init__(self, intent_detector):
        self.intent_detector = intent_detector

        # Explicit overrides by user
        self._force_neutral = re.compile(r"\b(düz|direkt|sadece cevap|sadece yanıt|şaka yapma|espri yapma)\b", re.IGNORECASE)
        self._force_serious = re.compile(r"\b(ciddi|acil|önemli|resmi|detaylı|detayli)\b", re.IGNORECASE)
        self._force_playful = re.compile(r"\b(şaka|espri|gül|haha|lol)\b", re.IGNORECASE)

        # Playful cues
        self._playful_cues = re.compile(r"(😂|😅|🤣|😄|😁|:d|xd|\bhaha\b|\blol\b|\bkanka\b|\babi\b|\byaaa\b)", re.IGNORECASE)

        # Friendly cues
        self._friendly_cues = re.compile(r"(selam|merhaba|nasılsın|naber|teşekkür|sağol)", re.IGNORECASE)

        # Serious cues
        self._serious_cues = re.compile(r"(rapor|hata|debug|log|stack|trace|prod|üretim|güvenlik|risk)", re.IGNORECASE)

    def detect(self, user_text: str, session: dict[str, Any]) -> ConversationTone:
        t = (user_text or "").strip()
        ctx = session.setdefault("context", {})
        last = (ctx.get("tone") or ConversationTone.NEUTRAL.value).strip().lower()

        # 1) Explicit overrides
        if self._force_neutral.search(t):
            tone = ConversationTone.NEUTRAL
            ctx["tone"] = tone.value
            return tone

        if self._force_serious.search(t):
            tone = ConversationTone.SERIOUS
            ctx["tone"] = tone.value
            return tone

        if self._force_playful.search(t):
            tone = ConversationTone.PLAYFUL
            ctx["tone"] = tone.value
            return tone

        # 2) If the query is clearly a tool query, default to NEUTRAL unless user is playful
        if self.intent_detector.is_math_query(t) or self.intent_detector.is_time_query(t):
            if self._playful_cues.search(t):
                tone = ConversationTone.PLAYFUL
            else:
                tone = ConversationTone.NEUTRAL
            ctx["tone"] = tone.value
            return tone

        # 3) Heuristics
        if self._serious_cues.search(t):
            tone = ConversationTone.SERIOUS
            ctx["tone"] = tone.value
            return tone

        if self._playful_cues.search(t):
            tone = ConversationTone.PLAYFUL
            ctx["tone"] = tone.value
            return tone

        if self._friendly_cues.search(t):
            tone = ConversationTone.FRIENDLY
            ctx["tone"] = tone.value
            return tone

        # 4) Fall back to last tone (context continuity)
        try:
            tone = ConversationTone(last)
        except Exception:
            tone = ConversationTone.NEUTRAL

        ctx["tone"] = tone.value
        return tone