# core/agent_core_constants.py
from __future__ import annotations

import re

# ======================
# CONSTANTS
# ======================

CONF_FORCE_ASK = 0.45

# Turkish "nasıl / nasil" fallback
HOW_TO_FALLBACK_RE = re.compile(r"\b(nasil|nasıl)\b", re.IGNORECASE)

# Trivial messages
TRIVIAL_SET = {
    "hm", "hmm", "hıh", "hih",
    "ok", "okay", "tamam", "peki", "olur",
    "evet", "hayır", "hayir",
    "anladım", "anladim",
    "??", "???", ".", "..", "...",
}