
# -- coding: utf-8 --
import re
from typing import Any, Dict, Optional

from openai import OpenAI


class ActionEngine:
    """
    Executes the decision by producing the user-facing output (or tool/action placeholder).
    Separate from decision so the agent feels like it 'chooses' then 'acts'.
    """

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model

        self._destructive_patterns = [
            r"\b(bilgisayarı|pc|computer)\s+kapat\b",
            r"\bshutdown\b",
            r"\byeniden\s+başlat\b",
            r"\brestart\b",
            r"\breboot\b",
            r"\bfabrika\s+ayar(lar)?\b",
            r"\breset\b",
            r"\bformat\b",
            r"\bdelete\b",
            r"\bsil\b.*\b(dosya|klasör|folder|file)\b",
            r"\buninstall\b",
            r"\bkaldır\b.*\b(program|uygulama|app)\b",
            r"\bkill\b",
            r"\bsonlandır\b",
            r"\bdurdur\b.*\b(süreç|process)\b",
            r"\bstop\b.*\b(service|servis)\b",
        ]

        # Deterministic ask helpers (improve "ask" quality without LLM)
        self._deictic_only = re.compile(r"^\s*(bunu|şunu|sunu|onu)\s*$", re.IGNORECASE)
        self._deictic_do = re.compile(r"^\s*(bunu|şunu|sunu|onu)\s+(yap|et)\s*$", re.IGNORECASE)
        self._action_only = re.compile(
            r"^\s*(sil|kapat|aç|ac|başlat|baslat|durdur|oynat|ekle|degistir|değiştir)\s*$",
            re.IGNORECASE,
        )

    def _run_llm(self, messages: list[dict], temperature: float) -> str:
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
        )
        return (resp.choices[0].message.content or "").strip()

    # -------------------------
    # Short/Long intent helpers
    # -------------------------

    def _user_explicitly_wants_short(self, user_text: str) -> bool:
        t = (user_text or "").strip().lower()
        if not t:
            return False
        cues = [
            "kısa", "kisa", "kısaca", "kisaca",
            "özet", "ozet", "kısa özet", "kisa ozet",
            "brief", "tl;dr", "tldr", "too long"
        ]
        return any(cue in t for cue in cues)

    def _user_explicitly_wants_long(self, user_text: str) -> bool:
        t = (user_text or "").strip().lower()
        if not t:
            return False
        cues = [
            "detay", "detaylı", "detayli",
            "ayrıntı", "ayrıntılı", "ayrintili",
            "uzun", "geniş", "genis",
            "adım adım", "adim adim",
            "açıkla", "acikla",
        ]
        return any(cue in t for cue in cues)

    def _shorten_output(self, text: str) -> str:
        """
        Enforce short output without breaking words.

        NOTE: We keep this function for ACT mode only (commands/instructions).
        For normal respond(), we do ChatGPT-style shortness: the model writes short.
        """
        if not text:
            return text

        # Keep shutdown command if present
        m = re.search(r"(shutdown\s*/[^\n\r]+)", text, flags=re.IGNORECASE)
        if m:
            return m.group(1).strip()

        # Normalize whitespace
        s = " ".join(text.split()).strip()
        if not s:
            return ""

        # Sentence-based: take first 1-2 sentences (., ?, !)
        sentences = re.findall(r"[^.!?]+[.!?]+", s)
        if sentences:
            first = sentences[0].strip()
            second = sentences[1].strip() if len(sentences) > 1 else ""
            out = first if not second else f"{first} {second}"
            if len(out) > 220:
                out = self._cut_at_space(out, 220)
            return out

        # No punctuation: cut at nearest whitespace
        return self._cut_at_space(s, 180)

    def _cut_at_space(self, s: str, limit: int) -> str:
        s = (s or "").strip()
        if len(s) <= limit:
            return s

        cut = s.rfind(" ", 0, limit)
        if cut == -1:
            return s[: limit - 1].rstrip() + "…"

        return s[:cut].rstrip() + "…"

    # -------------------------
    # "ONE QUESTION" enforcement
    # -------------------------

    def _one_question_only(self, text: str) -> str:
        if not text:
            return "Neyi kast ediyorsun?"

        t = " ".join(text.split())

        qm = t.find("?")
        if qm != -1:
            return t[: qm + 1].strip()

        t = t.rstrip(".! ")
        if len(t) > 0:
            return t + "?"
        return "Neyi kast ediyorsun?"

    # -------------------------
    # Deterministic ASK templates
    # -------------------------

    def _normalize_for_intent(self, text: str) -> str:
        t = (text or "").strip().lower()
        # keep Turkish chars + spaces; drop punctuation
        t = re.sub(r"[^\w\sçğıöşü]", " ", t)
        t = re.sub(r"\s+", " ", t).strip()
        return t

    def _deterministic_ask(self, user_text: str) -> Optional[str]:
        """
        Return a better SINGLE clarifying question for common ambiguous cases.
        If not applicable, return None and let LLM generate the question.
        """
        raw = (user_text or "").strip()
        if not raw:
            return "Tam olarak ne hakkında konuşmamı istersin?"

        t = self._normalize_for_intent(raw)

        # ✅ SPECIAL CASE: "nasıl/nasil ..." but object is missing
        # These must ask for the missing object, NOT "hangi konuda konuşalım"
        if t.startswith("nasıl") or t.startswith("nasil"):
            # "nasıl açarım"
            if " aç" in f" {t} " or " ac" in f" {t} ":
                return "Neyi açmamı istiyorsun?"
            # "nasıl yaparım"
            if " yap" in f" {t} ":
                return "Neyi yapmamı istiyorsun?"
            # "nasıl kurarım"
            if " kur" in f" {t} ":
                return "Neyi kurmamı istiyorsun?"
            # fallback still object-focused
            return "Tam olarak neyi yapmak istiyorsun?"

        # ✅ SPECIAL CASE: "wifi aç" -> ask target device (this is your FAIL #20)
        if ("wifi" in t or "wi fi" in t or "wi-fi" in t) and ("aç" in t or "ac" in t):
            return "Wi-Fi’yi hangi cihazda açmak istiyorsun: telefon mu bilgisayar mı?"

        # 1) Pure deictic: "bunu / şunu / onu"
        if self._deictic_only.match(t):
            return "Bunu derken neyi kastediyorsun: önceki konu mu, yoksa bir şey yapmam mı?"

        # 2) Deictic + do: "bunu yap"
        if self._deictic_do.match(t):
            return "Bunu derken neyi yapmamı istiyorsun?"

        # 3) Single action verb: "sil / kapat / aç / başlat / durdur"
        if self._action_only.match(t):
            v = t  # single token
            if v in {"sil"}:
                return "Neyi silmemi istiyorsun?"
            if v in {"kapat"}:
                return "Neyi kapatmamı istiyorsun?"
            if v in {"aç", "ac"}:
                return "Neyi açmamı istiyorsun?"
            if v in {"başlat", "baslat"}:
                return "Neyi başlatmamı istiyorsun?"
            if v in {"durdur"}:
                return "Neyi durdurmamı istiyorsun?"
            if v in {"oynat"}:
                return "Neyi oynatmamı istiyorsun?"
            if v in {"ekle"}:
                return "Neyi eklememi istiyorsun?"
            if v in {"degistir", "değiştir"}:
                return "Neyi değiştirmemi istiyorsun?"
            return "Tam olarak ne yapmamı istiyorsun?"

        # 4) Very short ambiguous messages (1-2 words) that are not obvious questions
        words = t.split()
        if len(words) <= 2 and "?" not in raw:
            # avoid turning greetings into ask
            if t not in {"selam", "merhaba", "hey", "hi"}:
                return "Tam olarak ne hakkında konuşmamı istersin?"

        return None

    # -------------------------
    # Core response actions
    # -------------------------

    def _ensure_system_prompt(self, system_prompt: str, convo_messages: list[dict]) -> list[dict]:
        msgs = list(convo_messages or [])
        if not msgs or msgs[0].get("role") != "system":
            return [{"role": "system", "content": system_prompt}] + msgs
        return msgs

    def respond(
        self,
        system_prompt: str,
        memory_note: Optional[str],
        convo_messages: list[dict],
        user_text: str,
        temperature: float,
        prefer_short: bool = False,
    ) -> str:
        msgs = self._ensure_system_prompt(system_prompt, convo_messages)

        if memory_note:
            msgs.append({"role": "system", "content": memory_note})

        # 🔥 JARVIS PERSONALITY CORE
        msgs.append({
            "role": "system",
            "content": """
        You are Jarvis.
        Speak like a decisive autonomous AI.

        RULES:

        - Avoid weak language like:
        olabilir, belki, muhtemelen, kontrol edebilirsin,
        istersen, faydalı olabilir

        - Do NOT sound like customer support.
        - When real-world data exists → make conclusions.
        - Be confident.
        - Be clear.
        - Be intelligent.
        - Never ramble.

        GOOD:
        "Yarın yağmur bekleniyor. Arabayı bugün yıkaman daha mantıklı."

        BAD:
        "Yarın yağmur olabilir, kontrol etmen iyi olabilir."
        """
        })


        # RULE:
        # - User explicit long => never enforce short
        # - User explicit short => enforce short
        # - Preference short => enforce short (unless user asked long)
        if self._user_explicitly_wants_long(user_text):
            enforce_short = False
        else:
            enforce_short = self._user_explicitly_wants_short(user_text) or prefer_short

        if enforce_short:
            msgs.append({
                "role": "system",
                "content": (
                    "Kısa cevap ver: en fazla 2 cümle, tek paragraf. "
                    "Sonuna soru ekleme. "
                    "Kelime/cümle kesme yapma. "
                    "Gereksiz detay ekleme."
                )
            })

        msgs.append({"role": "user", "content": user_text})

        reply = self._run_llm(msgs, temperature=temperature)
        return reply

    def ask_one_clarifying_question(
        self,
        system_prompt: str,
        memory_note: Optional[str],
        convo_messages: list[dict],
        user_text: str,
    ) -> str:
        # ✅ FIRST: deterministic high-quality ask (no LLM)
        det = self._deterministic_ask(user_text)
        if det:
            return self._one_question_only(det)

        sys = system_prompt + "\n\n" + """
Ask exactly ONE clarifying question.
Keep it short and specific. Do not ask multiple questions. Output only the question.
""".strip()

        msgs = [{"role": "system", "content": sys}]
        msgs.extend((convo_messages or [])[-12:])
        if memory_note:
            msgs.append({"role": "system", "content": memory_note})
        msgs.append({"role": "user", "content": user_text})

        reply = self._run_llm(msgs, temperature=0.6)
        reply = self._one_question_only(reply)
        return reply

    def idle_ack(self, system_prompt: str) -> str:
        return "Hm."

    # -------------------------
    # Safety helpers for ACT
    # -------------------------

    def _is_destructive_action(self, user_text: str) -> bool:
        t = (user_text or "").strip().lower()
        return any(re.search(p, t) for p in self._destructive_patterns)

    def _confirmation_question(self, user_text: str) -> str:
        return "Bu geri dönüşsüz bir işlem olabilir. Emin misin?"

    # -------------------------
    # ACT placeholder
    # -------------------------

    def act_placeholder(
        self,
        system_prompt: str,
        memory_note: Optional[str],
        convo_messages: list[dict],
        user_text: str,
        decision: Dict[str, Any],
        prefer_short: bool = False,
    ) -> str:
        """
        Tooling not implemented yet. This function must be safe.
        """
        if self._is_destructive_action(user_text):
            return self._confirmation_question(user_text)

        sys = system_prompt + "\n\n" + """
The user wants you to take a real-world action.
If details are missing, ask exactly ONE clarifying question.
If details are sufficient, give the shortest actionable instruction.
Do NOT claim you already performed the action.
Do NOT mention internal tools or architecture.
""".strip()

        msgs = [{"role": "system", "content": sys}]
        msgs.extend((convo_messages or [])[-12:])
        if memory_note:
            msgs.append({"role": "system", "content": memory_note})
        msgs.append({"role": "user", "content": user_text})

        reply = self._run_llm(msgs, temperature=0.6)

        if "?" in reply:
            reply = self._one_question_only(reply)

        if prefer_short and not self._user_explicitly_wants_long(user_text):
            reply = self._shorten_output(reply)

        return reply