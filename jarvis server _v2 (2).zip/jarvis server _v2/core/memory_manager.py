from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional

from core.memory_filter import MemoryFilter
from core.memory.identity_memory import IdentityMemory
from core.memory.conversation_memory import ConversationMemory


class MemoryManager:
    """
    Jarvis durable memory manager.

    Artık görevler bölündü:

    IdentityMemory      -> isim / kimlik
    ConversationMemory  -> konuşma logu
    MemoryFilter        -> çöplük engelleme
    """

    _ALLOWED_PREF_KEYS = {"reply_style", "tone_preference", "preferred_name"}

    # ------------------------------------------------

    def __init__(self, memory_path: str = "memory.json"):

        self.path = memory_path
        self.filter = MemoryFilter()

        # forget patterns
        self._forget_patterns = [
            re.compile(r"\bbeni\s+unut\b", re.IGNORECASE),
            re.compile(r"\bhafızayı\s+sıfırla\b", re.IGNORECASE),
            re.compile(r"\bhafizayi\s+sifirla\b", re.IGNORECASE),
            re.compile(r"\bmemory\s+reset\b", re.IGNORECASE),
            re.compile(r"\bforget\s+me\b", re.IGNORECASE),
        ]

        # persistence cue
        self._persistent_cues = re.compile(
            r"\b(bundan\s+sonra|artık|her\s+zaman|daima|hep)\b",
            re.IGNORECASE,
        )

        # preference patterns
        self._pref_short = re.compile(r"\b(kısa|kisa)\s+(cevap|konuş|konus)\b", re.IGNORECASE)
        self._pref_serious = re.compile(r"\b(ciddi|resmi)\s+(konuş|konus)\b", re.IGNORECASE)
        self._pref_playful = re.compile(r"\b(şaka|espri)\s+(yap|yapabilirsin|serbest)\b", re.IGNORECASE)

        # LOAD MEMORY FIRST
        self._load_memory()

        # 🔥 NEW MODULAR SYSTEM
        self.identity = IdentityMemory(self.memory)
        self.conversation = ConversationMemory(self.memory, self.filter)

    # =========================================================
    # IO
    # =========================================================

    def _load_memory(self) -> None:

        if not os.path.exists(self.path):
            self.memory = {
                "user_info": {},
                "conversations": [],
                "preferences": {},
                "long_term": {},
            }
            return

        try:
            with open(self.path, "r", encoding="utf-8") as f:
                obj = json.load(f)

            if isinstance(obj, dict):
                self.memory = obj
                self.memory.setdefault("user_info", {})
                self.memory.setdefault("conversations", [])
                self.memory.setdefault("preferences", {})
                self.memory.setdefault("long_term", {})
            else:
                raise ValueError("memory json invalid")

        except Exception:
            self.memory = {
                "user_info": {},
                "conversations": [],
                "preferences": {},
                "long_term": {},
            }

    # ------------------------------------------------

    def save(self) -> None:
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.memory, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    # =========================================================
    # FORGET
    # =========================================================

    def should_forget(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        return any(p.search(t) for p in self._forget_patterns)

    def forget_all(self) -> None:
        self.memory = {
            "user_info": {},
            "conversations": [],
            "preferences": {},
            "long_term": {},
        }
        self.save()

    # =========================================================
    # CONVERSATION
    # =========================================================

    def save_conversation_turn(
        self,
        user_text: str,
        response: str,
        flush: bool = True,
    ) -> None:
        """
        CORE MEMORY GATE
        """

        # ✅ isim HER ZAMAN yakalanır (filter bypass)
        name = self.identity.extract_name(user_text)
        if name:
            self.identity.save_user_name(name)

        # ✅ conversation filter kontrollü
        wrote = self.conversation.save_turn(user_text, response)

        if flush and (wrote or name):
            self.save()

    # =========================================================
    # USER
    # =========================================================

    def get_user_name(self) -> Optional[str]:
        return self.identity.get_user_name()

    # =========================================================
    # PREFERENCES
    # =========================================================

    def extract_preference(self, text: str) -> Dict[str, Any]:

        t_raw = (text or "").strip()
        if not t_raw:
            return {}

        prefs: Dict[str, Any] = {}

        persistent = bool(self._persistent_cues.search(t_raw))

        # name preference
        n = self.identity.extract_name(t_raw)
        if n:
            prefs["preferred_name"] = n
            prefs["_set_user_name"] = n

        if persistent and self._pref_short.search(t_raw):
            prefs["reply_style"] = "short"

        if persistent and self._pref_serious.search(t_raw):
            prefs["tone_preference"] = "serious"

        if persistent and self._pref_playful.search(t_raw):
            prefs["tone_preference"] = "playful"

        return prefs

    # ------------------------------------------------

    def apply_preference(self, prefs: Dict[str, Any]) -> None:

        if not prefs:
            return

        n = prefs.get("_set_user_name")
        if isinstance(n, str) and n.strip():
            self.identity.save_user_name(n.strip())

        safe: Dict[str, Any] = {}

        for k in self._ALLOWED_PREF_KEYS:
            if k in prefs:
                safe[k] = prefs[k]

        if safe:
            self.memory.setdefault("preferences", {}).update(safe)
            self.save()

    # ------------------------------------------------

    def get_preference(self, key: str, default: Any = None) -> Any:
        return self.memory.get("preferences", {}).get(key, default)

    # =========================================================
    # GOALS
    # =========================================================

    def set_long_term(self, key: str, value: Any) -> None:

        if not key:
            return

        self.memory.setdefault("long_term", {})
        self.memory["long_term"][key] = value
        self.save()

    def get_long_term(self, key: str, default: Any = None) -> Any:
        return self.memory.get("long_term", {}).get(key, default)

    def get_goals(self, limit: int = 5) -> List[str]:

        lt = self.memory.get("long_term", {})

        if not isinstance(lt, dict):
            return []

        goals = [
            k.replace("goal_", "")
            for k, v in lt.items()
            if k.startswith("goal_") and v is True
        ]

        return goals[:limit]

    # =========================================================
    # RETRIEVAL
    # =========================================================

    def get_relevant_memories(self, query: str, limit: int = 3) -> List[str]:

        q = (query or "").strip().lower()
        relevant: List[str] = []

        name = self.identity.get_user_name()
        if name and ("adım" in q or "adim" in q or "isim" in q):
            relevant.append(f"Kullanıcının adı: {name}")

        prefs = self.memory.get("preferences", {})
        if isinstance(prefs, dict):
            for key, value in prefs.items():
                if str(key).lower() in q:
                    relevant.append(f"Tercih: {key} = {value}")

        return relevant[:limit]