from openai import OpenAI
import json

client = OpenAI()

SYSTEM_PROMPT = """
You are the long-term cognition module of an advanced AI.

Your ONLY job is to detect whether the user is expressing
a REAL life goal or habit change.

Return STRICT JSON only:

{
  "goal": "health | productivity | learning | finance | social | none",
  "confidence": 0.0-1.0,
  "reason": "short"
}

Rules:

- Detect ONLY real behavioral commitments.
- Ignore casual talk.
- Ignore temporary plans.
- Confidence must reflect certainty.

Examples:

User: "I will start exercising regularly"
{
 "goal":"health",
 "confidence":0.92,
 "reason":"commitment to exercise"
}

User: "maybe I should study more"
{
 "goal":"learning",
 "confidence":0.65,
 "reason":"weak intention"
}

User: "hello"
{
 "goal":"none",
 "confidence":0.1,
 "reason":"no commitment"
}
"""


def detect_goal(user_text: str) -> dict:
    try:
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            temperature=0,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_text},
            ],
        )

        content = response.choices[0].message.content.strip()

        return json.loads(content)

    except Exception:
        return {
            "goal": "none",
            "confidence": 0.0,
            "reason": "llm_failure"
        }