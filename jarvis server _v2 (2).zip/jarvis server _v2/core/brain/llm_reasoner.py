from openai import OpenAI
import json

client = OpenAI()

SYSTEM_PROMPT = """
You are the cognitive brain of an advanced AI assistant.

Your role is NOT to chat.
Your role is to decide what the system should do next.

You MUST respond ONLY with valid JSON.

Available actions:

RESPOND  -> normal response
ASK      -> ask a clarification question
TOOL     -> call a tool
IGNORE   -> no action needed

Available tools:
- weather
- time
- math

Rules:

- Never chat.
- Never explain yourself.
- Never output anything except JSON.
- Keep reasoning short.
- If tool is required, ALWAYS provide tool_name.

Examples:

User: "what time is it?"
Output:
{
  "action": "TOOL",
  "tool_name": "time",
  "reason": "User is asking current time"
}

User: "hello"
Output:
{
  "action": "RESPOND",
  "reason": "User is greeting"
}

User: "is tomorrow good for a picnic?"
Output:
{
  "action": "TOOL",
  "tool_name": "weather",
  "reason": "Weather information is required"
}
"""


def reason(user_text: str) -> dict:
    """
    Sends the user message to the LLM and returns the decision JSON.
    """

    try:
        response = client.chat.completions.create(
            model="gpt-4.1-mini",   # hızlı + ucuz + güçlü
            temperature=0,         # deterministik kararlar
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_text},
            ],
        )

        content = response.choices[0].message.content.strip()

        # JSON parse
        decision = json.loads(content)

        # basic safety check
        if "action" not in decision:
            raise ValueError("Invalid decision format")

        return decision

    except Exception as e:
        # Guardian fallback
        return {
            "action": "RESPOND",
            "reason": f"LLM failure: {str(e)}"
        }