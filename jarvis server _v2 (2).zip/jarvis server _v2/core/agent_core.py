from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.decision import DecisionEngine as LLMDecisionEngine
from core.actions import ActionEngine
from core.memory_manager import MemoryManager
from core.intent_detector import IntentDetector
from core.decision_engine import DecisionEngine as RuleDecisionEngine, DecisionIntent

from core.agent_core_constants import CONF_FORCE_ASK
from core.agent_core_utils import is_trivial, trim_messages, build_memory_note
from core.agent_core_decision import normalize_intent, clamp_confidence, should_force_ask

from core.cognition.planner_engine import PlannerEngine
from core.consciousness.session_trace import SessionTrace


class AgentCore:

    def __init__(
        self,
        client,
        model: str,
        memory_manager: MemoryManager,
        system_prompt: str,
        tool_handler,
        temperature: float = 0.7,
        max_messages: int = 50,
        keep_last: int = 40,
        intent_detector: Optional[IntentDetector] = None,
    ):
        self.client = client
        self.model = model
        self.memory = memory_manager

        self.system_prompt = (system_prompt or "").strip()
        self.temperature = float(temperature)

        self.max_messages = max_messages
        self.keep_last = keep_last

        self.decision = LLMDecisionEngine(client=client, model=model)
        self.actions = ActionEngine(client=client, model=model)

        self.rule_decision = RuleDecisionEngine()
        self.intent_detector = intent_detector or IntentDetector()

        self.tool_handler = tool_handler

        # Planner client parametresi bazı sürümlerde yok olabilir → safe init
        try:
            self.planner = PlannerEngine(
                tool_handler=self.tool_handler,
                memory=self.memory,
                client=client
            )
        except TypeError:
            self.planner = PlannerEngine(
                tool_handler=self.tool_handler,
                memory=self.memory
            )

    # ------------------------------------------------

    def _prefer_short(self) -> bool:
        try:
            v = self.memory.get_preference("reply_style", None)
            return str(v).strip().lower() == "short"
        except Exception:
            return False

    # ------------------------------------------------

    def _write_goals_from_planner(self, planner_context):
        if not planner_context:
            return

        goals = planner_context.get("goals")
        if not goals:
            return

        for g in goals:
            key = f"goal_{g}"
            self.memory.set_long_term(key, True)

    # ------------------------------------------------

    def _build_dynamic_system(self, memory_note, goals):

        dynamic = self.system_prompt

        if memory_note:
            dynamic += f"\n\nUSER MEMORY:\n{memory_note}"

        if goals:
            goal_text = "\n".join(f"- {g}" for g in goals)
            dynamic += f"\n\nACTIVE GOALS:\n{goal_text}"

        return dynamic

    # ------------------------------------------------

    def process_chat(
        self,
        user_text: str,
        session: Dict[str, Any],
        session_id: str = "default",
    ) -> str:

        user_text = (user_text or "").strip()
        messages: List[Dict[str, str]] = session.get("messages", []).copy()

        if "trace" not in session:
            session["trace"] = SessionTrace()

        trace: SessionTrace = session["trace"]

        memory_note = build_memory_note(self.memory, user_text)

        try:
            goals = self.memory.get_goals(limit=3)
        except Exception:
            goals = []

        dynamic_system = self._build_dynamic_system(memory_note, goals)

        # SYSTEM her zaman başta
        if messages and messages[0].get("role") == "system":
            messages[0] = {"role": "system", "content": dynamic_system}
        else:
            messages.insert(0, {"role": "system", "content": dynamic_system})

        call_messages = messages.copy()

        # ================= PLANNER =================

        planner_context = self.planner.evaluate(user_text)
        self._write_goals_from_planner(planner_context)

        tool_available = False

        forced_intent = None

        # ================= TOOL DOMINATION =================

        if tool_available:

            tool_data = "\n".join(planner_context.get("tool_data", []))
            risk = planner_context.get("risk_detected")

            tool_system = f"""
CRITICAL SYSTEM DIRECTIVE:

Tool data is REAL WORLD DATA.
Never ignore it.
Never hallucinate.
Never give generic advice.

TOOL DATA:
{tool_data}

RISK DETECTED: {risk}

MANDATORY BEHAVIOR:
- Use tool data
- If risk=True → clearly warn
- Be specific
""".strip()

            call_messages.insert(1, {
                "role": "system",
                "content": tool_system
            })

            call_messages.append({
                "role": "user",
                "content": user_text
            })

            forced_intent = "respond"

        else:

            call_messages.append({"role": "user", "content": user_text})

            d0 = self.rule_decision.decide(
                user_text=user_text,
                is_ambiguous=self.intent_detector.is_ambiguous(user_text),
                is_action_request=self.intent_detector.is_action_request(user_text),
                is_trivial=is_trivial(user_text),
                tool_available=False,
            )

            run_llm = d0.intent not in (
                DecisionIntent.IDLE,
                DecisionIntent.ASK,
            )

            if not run_llm:

                trace.record_decision(
                    intent=d0.intent.value,
                    confidence=1.0,
                    reason="rule_decision",
                )

                if d0.intent == DecisionIntent.IDLE:
                    return self.actions.idle_ack(dynamic_system)

                return self.actions.ask_one_clarifying_question(
                    system_prompt=dynamic_system,
                    memory_note=memory_note,
                    convo_messages=call_messages,
                    user_text=user_text,
                )

        prefer_short = self._prefer_short()

        # ================= LLM =================

        decision = self.decision.decide(
            user_text=user_text,
            memory_note=memory_note,
            last_messages=call_messages[-10:],
        )

        intent = normalize_intent(decision.get("intent"))
        conf = clamp_confidence(decision.get("confidence"))

        if forced_intent:
            intent = forced_intent

        trace.record_decision(
            intent=intent,
            confidence=conf,
            reason=decision.get("reason", "llm_decision"),
        )

        if should_force_ask(intent, conf, CONF_FORCE_ASK):
            intent = "ask"

        if intent == "ask":
            response = self.actions.ask_one_clarifying_question(
                system_prompt=dynamic_system,
                memory_note=memory_note,
                convo_messages=call_messages,
                user_text=user_text,
            )
        else:
            response = self.actions.respond(
                system_prompt=dynamic_system,
                memory_note=memory_note,
                convo_messages=call_messages,
                user_text=user_text,
                temperature=self.temperature,
                prefer_short=prefer_short,
            )

        response = (response or "").strip() or "Devam et."

        messages.append({"role": "user", "content": user_text})
        messages.append({"role": "assistant", "content": response})

        session["messages"] = trim_messages(messages, self.max_messages, self.keep_last)

        return response