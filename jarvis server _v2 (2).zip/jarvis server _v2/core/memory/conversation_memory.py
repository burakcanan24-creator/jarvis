from __future__ import annotations

import time
from typing import Any

from core.memory_filter import MemoryFilter


class ConversationMemory:
    def __init__(self, memory: dict, mem_filter: MemoryFilter):
        self.memory = memory
        self.filter = mem_filter

    def save_turn(self, user_text: str, response: str) -> bool:
        # True = yazdı, False = yazmadı
        if not self.filter.should_store(user_text):
            return False

        turn = {"user": user_text, "assistant": response, "ts": time.time()}
        self.memory.setdefault("conversations", []).append(turn)

        conv = self.memory["conversations"]
        if len(conv) > 100:
            self.memory["conversations"] = conv[-100:]

        return True