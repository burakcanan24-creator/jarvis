from __future__ import annotations

import re
from typing import Optional


class IdentityMemory:
    def __init__(self, memory: dict):
        self.memory = memory

        self._name_blacklist = {
            "kim", "kimim", "kimsin", "kimiz",
            "ne", "neyim", "nesin", "neyiz",
            "kullanıcı", "kullanicı", "user", "misafir",
            "insan", "biri", "birisi",
        }

        self._name_query_re = re.compile(r"\b(adım|adim|isim|ad)\b", re.IGNORECASE)

        self._preferred_name_patterns = [
            re.compile(r'\bbana\s+["“”\']?([a-zçğıöşü]{2,})["“”\']?\s+de\b', re.IGNORECASE),
            re.compile(r'\bbana\s+["“”\']?([a-zçğıöşü]{2,})["“”\']?\s+diye\s+hitap\s+et\b', re.IGNORECASE),
            re.compile(r'\bbana\s+["“”\']?([a-zçğıöşü]{2,})["“”\']?\s+diye\s+seslen\b', re.IGNORECASE),
            re.compile(r'\bbana\s+["“”\']?([a-zçğıöşü]{2,})["“”\']?\s+diye\s+çağır\b', re.IGNORECASE),
            re.compile(r'\bbana\s+["“”\']?([a-zçğıöşü]{2,})["“”\']?\s+diye\s+cag[ıi]r\b', re.IGNORECASE),
            re.compile(r'\bbana\s+["“”\']?([a-zçğıöşü]{2,})["“”\']?\s+olarak\s+hitap\s+et\b', re.IGNORECASE),
        ]

    # -------------------------
    # Name core
    # -------------------------

    def _sanitize_name(self, name: str) -> Optional[str]:
        if not name:
            return None
        n = name.strip().lower()
        n = re.sub(r"[^\wçğıöşü]", "", n)
        if len(n) < 2:
            return None
        if n in self._name_blacklist:
            return None
        if n.endswith(("miyim", "misin", "miyiz", "musun", "müsün", "muyum", "muyuz")):
            return None
        return n[0].upper() + n[1:]

    def _norm_text_keep_tr(self, text: str) -> str:
        t = (text or "").strip().lower()
        if not t:
            return ""
        t = re.sub(r"[^\w\sçğıöşü\"“”']", " ", t)
        t = re.sub(r"\s+", " ", t).strip()
        return t

    def _extract_preferred_name_from_text(self, text: str) -> Optional[str]:
        t = self._norm_text_keep_tr(text)
        if not t:
            return None

        for pat in self._preferred_name_patterns:
            m = pat.search(t)
            if m:
                cand = self._sanitize_name(m.group(1))
                if cand:
                    return cand
        return None

    def extract_name(self, text: str) -> Optional[str]:
        raw = (text or "").strip()
        if not raw:
            return None

        t = self._norm_text_keep_tr(raw)
        if not t:
            return None

        if "ben kimim" in t or "adım ne" in t or "adim ne" in t or "ismim ne" in t:
            return None

        m1 = re.search(
            r"\b(benim\s+adım|benim\s+adim|adım|adim|ismim)\s+([a-zçğıöşü]{2,})\b",
            t,
        )
        if m1:
            return self._sanitize_name(m1.group(2))

        pn = self._extract_preferred_name_from_text(raw)
        if pn:
            return pn

        return None

    def save_user_name(self, name: str) -> None:
        name = (name or "").strip()
        if not name:
            return
        self.memory.setdefault("user_info", {})["name"] = name

    def get_user_name(self) -> Optional[str]:
        v = self.memory.get("user_info", {}).get("name")
        if isinstance(v, str) and v.strip():
            return v.strip()
        return None

    def is_name_query(self, text: str) -> bool:
        return bool(self._name_query_re.search(text or ""))