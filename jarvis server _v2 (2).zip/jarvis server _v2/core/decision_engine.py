from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Dict, Any

from core.brain.llm_reasoner import reason


# =========================
# INTENT ENUM
# =========================

class DecisionIntent(str, Enum):
    RESPOND = "respond"
    ASK = "ask"
    ACT = "act"
    IDLE = "idle"


# =========================
# DECISION RESULT
# =========================

@dataclass
class Decision:
    intent: DecisionIntent
    confidence: float
    reason: str
    meta: Dict[str, Any] | None = None


# =========================
# DECISION ENGINE (GUARDIAN + BRAIN HYBRID)
# =========================

class DecisionEngine:
    """
    Yeni rol:

    - Reflex kararları hızlı verir
    - Emin değilse LLM'e danışır
    - LLM saçmalarsa sistemi korur
    """

    def _init_(self):
        pass

    # -------------------------
    # PUBLIC API
    # -------------------------

    def decide(
        self,
        user_text: str,
        *,
        is_ambiguous: bool = False,
        is_action_request: bool = False,
        is_trivial: bool = False,
        tool_available: bool = False,
    ) -> Decision:

        text = (user_text or "").strip()

        # 🔥 HARD REFLEX (LLM'e gitmez)

        if not text:
            return Decision(
                intent=DecisionIntent.IDLE,
                confidence=1.0,
                reason="empty_input",
            )

        if is_trivial:
            return Decision(
                intent=DecisionIntent.IDLE,
                confidence=0.95,
                reason="trivial_input",
            )

        # 🔥 BELİRSİZLİK → LLM'E SOR
        if is_ambiguous:
            return self._llm_decide(text)

        # 🔥 AKSİYON İSTİYORSA
        if is_action_request:

            if tool_available:
                return Decision(
                    intent=DecisionIntent.ACT,
                    confidence=0.85,
                    reason="action_requested_fast_path",
                )

            # tool yoksa LLM karar versin
            return self._llm_decide(text)

        # 🔥 DEFAULT → LLM
        return self._llm_decide(text)

    # -------------------------
    # LLM DECISION
    # -------------------------

    def _llm_decide(self, text: str) -> Decision:

        brain = reason(text)

        action = brain.get("action", "RESPOND").upper()
        tool_name = brain.get("tool_name")

        # 🛑 GUARDIAN — LLM saçmalarsa sistemi koru
        if action not in {"RESPOND", "ASK", "TOOL", "IGNORE"}:
            return Decision(
                intent=DecisionIntent.RESPOND,
                confidence=0.3,
                reason="llm_invalid_action",
            )

        if action == "IGNORE":
            return Decision(
                intent=DecisionIntent.IDLE,
                confidence=0.6,
                reason="llm_ignore",
            )

        if action == "ASK":
            return Decision(
                intent=DecisionIntent.ASK,
                confidence=0.75,
                reason="llm_clarification",
            )

        if action == "TOOL":

            # tool adı yoksa güvenme
            if not tool_name:
                return Decision(
                    intent=DecisionIntent.ASK,
                    confidence=0.4,
                    reason="llm_tool_missing",
                )

            return Decision(
                intent=DecisionIntent.ACT,
                confidence=0.8,
                reason="llm_tool_decision",
                meta={"tool_name": tool_name},
            )

        # RESPOND
        return Decision(
            intent=DecisionIntent.RESPOND,
            confidence=0.7,
            reason="llm_respond",
        )