# core/agent_core_decision.py
from __future__ import annotations

from typing import Any, Dict

from core.decision_engine import DecisionIntent


CONF_FORCE_ASK = 0.45


def normalize_intent(raw: Any) -> str:
    intent = str(raw or "respond").strip().lower()
    if intent not in {"respond", "ask", "act", "idle"}:
        return "respond"
    return intent


def clamp_confidence(value: Any, default: float = 0.6) -> float:
    try:
        c = float(value)
    except Exception:
        c = default
    if c < 0.0:
        return 0.0
    if c > 1.0:
        return 1.0
    return c


def should_force_ask(intent: str, confidence: float, is_trivial: bool) -> bool:
    if is_trivial:
        return False
    return intent == "respond" and confidence < CONF_FORCE_ASK


def map_rule_decision(rule_decision) -> DecisionIntent:
    """
    Güvenli eşleme: rule_decision.intent beklenmeyen bir şeyse IDLE'a düşer.
    """
    try:
        if rule_decision.intent in (
            DecisionIntent.ASK,
            DecisionIntent.IDLE,
            DecisionIntent.ACT,
            DecisionIntent.RESPOND,
        ):
            return rule_decision.intent
    except Exception:
        pass
    return DecisionIntent.IDLE