from __future__ import annotations

import re


class MemoryFilter:
    """
    Jarvis'in çöplük olmasını engeller
    AMA kritik bilgileri ASLA kaçırmaz.
    """

    def __init__(self):

        # Uzun vadeli sinyaller
        self._patterns = [
            r"\badım\b",
            r"\badim\b",
            r"\bismim\b",
            r"\bbana .* de\b",
            r"\bbaşlıyorum\b",
            r"\bkarar verdim\b",
            r"\bhedefim\b",
            r"\bplanlıyorum\b",
            r"\brutin\b",
            r"\balışkanlık\b",
        ]

        self._compiled = [
            re.compile(p, re.IGNORECASE) for p in self._patterns
        ]

        # kesin çöpler
        self._ignore = [
            "saat kaç",
            "hava nasıl",
            "merhaba",
            "selam",
            "teşekkür",
            "sağol",
        ]

    # ------------------------------------------------

    def should_store(self, text: str) -> bool:

        if not text:
            return False

        t = text.lower()

        # çöpler
        if any(i in t for i in self._ignore):
            return False

        # güçlü sinyal varsa kaydet
        for pattern in self._compiled:
            if pattern.search(t):
                return True

        # ⚠️ kritik kural:
        # çok kısa mesaj değilse sakla
        if len(t.split()) >= 3:
            return True

        return False