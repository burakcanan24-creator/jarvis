import json
import os
from dataclasses import asdict
from typing import Optional, Dict

from core.user.user_model import UserProfile


class UserStore:
    """
    Basit local user store.
    Multi-user + permission için temel.
    """

    def __init__(self, path: str = "users.json"):
        self.path = (path or "users.json").strip() or "users.json"
        self._cache: Dict[str, UserProfile] = {}
        self._loaded = False

    # -------------------------
    # IO
    # -------------------------

    def _load(self) -> None:
        if self._loaded:
            return

        self._loaded = True
        if not os.path.exists(self.path):
            self._cache = {}
            return

        with open(self.path, "r", encoding="utf-8") as f:
            raw = json.load(f) or {}

        users = raw.get("users", {})
        out: Dict[str, UserProfile] = {}

        for user_id, data in users.items():
            if not isinstance(data, dict):
                continue

            out[user_id] = UserProfile(
                user_id=user_id,
                name=data.get("name"),
                role=data.get("role", "user"),
                voice_id=data.get("voice_id"),
                face_id=data.get("face_id"),
                preferences=data.get("preferences") or {},
                habits=data.get("habits") or {},
                goals=data.get("goals") or [],
                permissions=data.get("permissions") or [],
            )

        self._cache = out

    def _save(self) -> None:
        self._load()
        payload = {"users": {uid: asdict(p) for uid, p in self._cache.items()}}
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

    # -------------------------
    # PUBLIC
    # -------------------------

    def get(self, user_id: str) -> Optional[UserProfile]:
        self._load()
        uid = (user_id or "").strip()
        if not uid:
            return None
        return self._cache.get(uid)

    def upsert(self, profile: UserProfile) -> None:
        self._load()
        self._cache[profile.user_id] = profile
        self._save()

    def ensure_root(self, user_id: str, name: str | None = None) -> UserProfile:
        """
        İlk kurulum için root kullanıcı oluşturur.
        """
        self._load()
        uid = (user_id or "").strip() or "root"

        p = self._cache.get(uid)
        if p:
            # root değilse yükselt
            if p.role != "root":
                p.role = "root"
                self._save()
            return p

        p = UserProfile(
            user_id=uid,
            name=name or uid,
            role="root",
            permissions=["*"],
        )
        self._cache[uid] = p
        self._save()
        return p