from dataclasses import dataclass, field
from typing import Optional, List, Dict


@dataclass
class UserProfile:
    user_id: str
    name: Optional[str] = None
    role: str = "user"   # root / admin / user / guest

    # identity
    voice_id: Optional[str] = None
    face_id: Optional[str] = None

    # cognition
    preferences: Dict[str, str] = field(default_factory=dict)
    habits: Dict[str, str] = field(default_factory=dict)
    goals: List[str] = field(default_factory=list)

    # authority
    permissions: List[str] = field(default_factory=list)

    def is_root(self) -> bool:
        return self.role == "root"