import json
import re
from typing import Any, Dict, Optional

from openai import OpenAI


def _extract_json(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None

    t = text.strip()

    # Properly strip code fences like json ... 
    if t.startswith(""):
        # remove opening fence line
        t = re.sub(r"^[a-zA-Z0-9_-]\s", "", t)
        # remove closing fence
        t = re.sub(r"\s*```$", "", t).strip()

    # Try direct parse
    try:
        obj = json.loads(t)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass

    # Try to find a JSON object
    m = re.search(r"\{.*\}", t, flags=re.DOTALL)
    if m:
        try:
            obj = json.loads(m.group(0))
            if isinstance(obj, dict):
                return obj
        except Exception:
            return None

    return None


class DecisionEngine:
    """
    Makes a decision BEFORE responding.
    This is where 'agent-ness' comes from: choose what to do next.
    """

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model

        # stricter destructive patterns (avoid "konuyu kapat" etc)
        self._destructive_patterns = [
            r"\b(bilgisayarı|pc|computer)\s+kapat\b",
            r"\bshutdown\b",
            r"\byeniden\s+başlat\b",
            r"\brestart\b",
            r"\breboot\b",
            r"\bfabrika\s+ayar(lar)?\b",
            r"\breset\b",
            r"\bformat\b",
            r"\bdelete\b",
            r"\bsil\b.*\b(dosya|klasör|folder|file)\b",
            r"\buninstall\b",
            r"\bkaldır\b.*\b(program|uygulama|app)\b",
            r"\bkill\b",
            r"\bsonlandır\b",
            r"\bdurdur\b.*\b(süreç|process)\b",
            r"\bstop\b.*\b(service|servis)\b",
        ]

    def _looks_destructive(self, user_text: str) -> bool:
        t = (user_text or "").strip().lower()
        return any(re.search(p, t) for p in self._destructive_patterns)

    def decide(
        self,
        user_text: str,
        memory_note: str | None,
        last_messages: list[dict],
    ) -> Dict[str, Any]:
        """
        Returns a JSON decision dict.
        """
        sys = """
You are Jarvis's decision core.
Your job is to decide what to do next BEFORE generating the final user-facing text.

Return STRICT JSON only:

{
  "intent": "respond|ask|act|idle",
  "confidence": 0.0-1.0,
  "reason": "short",
  "target": "optional short label",
  "action": { "name": "optional", "args": { } }
}

Guidelines:
- "ask": when the user's message is ambiguous and you need ONE clarifying question.
- "respond": when you can answer now.
- "act": when a real-world tool/action should be invoked.
- "idle": when the best move is minimal acknowledgment.

IMPORTANT:
- If the user requests a potentially destructive/irreversible computer/device action (shutdown/restart/delete/reset/format/etc),
  choose intent="act" (so the action layer can ask for confirmation).

Do NOT output any text other than JSON.
""".strip()

        payload = {
            "user_message": user_text,
            "memory_note": memory_note or "",
            "recent_context": last_messages[-10:],
        }

        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": sys},
                {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
            ],
            temperature=0.2,
        )

        out = (resp.choices[0].message.content or "").strip()
        obj = _extract_json(out)

        # Hard fallback
        if not obj or "intent" not in obj:
            if self._looks_destructive(user_text):
                return {"intent": "act", "confidence": 0.6, "reason": "fallback_destructive"}
            return {"intent": "respond", "confidence": 0.4, "reason": "fallback"}

        intent = str(obj.get("intent", "respond")).strip().lower()
        if intent not in {"respond", "ask", "act", "idle"}:
            intent = "respond"

        # Force destructive -> act
        if self._looks_destructive(user_text):
            intent = "act"

        conf = obj.get("confidence", 0.6)
        try:
            conf = float(conf)
        except Exception:
            conf = 0.6
        conf = max(0.0, min(1.0, conf))

        reason = str(obj.get("reason", "")).strip()[:200]
        target = str(obj.get("target", "")).strip()[:80]
        action = obj.get("action", None)

        result: Dict[str, Any] = {
            "intent": intent,
            "confidence": conf,
            "reason": reason or "ok",
        }
        if target:
            result["target"] = target

        # sanitize action
        if isinstance(action, dict):
            act_name = action.get("name")
            act_args = action.get("args")
            sanitized = {}
            if isinstance(act_name, str) and act_name.strip():
                sanitized["name"] = act_name.strip()[:80]
            if isinstance(act_args, dict):
                sanitized["args"] = act_args
            if sanitized:
                result["action"] = sanitized

        return result