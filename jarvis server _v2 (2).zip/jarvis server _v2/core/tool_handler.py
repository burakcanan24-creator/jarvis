from __future__ import annotations

from core.tools.time_tool import TimeTool
from core.tools.math_tool import MathTool, MathError
from core.tools.weather_tool import WeatherTool, WeatherError


class ToolHandler:
    """
    Tool çağırır.
    İki mod vardır:

    1️⃣ RAW → LLM yorumlar
    2️⃣ STRING → fallback / hızlı cevap

    Exception ASLA yutulmaz.
    """

    def __init__(self):
        self.time_tool = TimeTool()
        self.math_tool = MathTool()
        self.weather_tool = WeatherTool()
        self._math_supported = "+, -, *, /, %"

    # =====================================================
    # 🔥 RAW METHODS (AGENT MODE)
    # =====================================================

    def get_weather_raw(self, city: str | None, day_offset: int | None = None):

        city = (city or "").strip()

        if not city:
            return {"error": "missing_city"}

        try:
            args = {"city": city}

            if isinstance(day_offset, int):
                args["mode"] = "forecast"
                args["day_offset"] = day_offset

            result = self.weather_tool.run(args)

            print("🌤 WEATHER RAW ->", result)

            if result.success:
                return result.data

            return {"error": result.error}

        except Exception as e:
            print("🔥 WEATHER RAW CRASH:", repr(e))
            raise

    def get_time_raw(self, timezone: str | None = None):

        try:
            args = {}
            if timezone:
                args["timezone"] = timezone

            result = self.time_tool.run(args)

            print("🕒 TIME RAW ->", result)

            if result.success:
                return result.data

            return {"error": result.error}

        except Exception as e:
            print("🔥 TIME RAW CRASH:", repr(e))
            raise

    def calculate_raw(self, expression: str):

        expression = (expression or "").strip()

        if not expression:
            return {"error": "missing_expression"}

        try:
            result = self.math_tool.run({"expression": expression})

            print("🧮 MATH RAW ->", result)

            if result.success:
                return result.data

            return {"error": result.error}

        except Exception as e:
            print("🔥 MATH RAW CRASH:", repr(e))
            raise

    # =====================================================
    # STRING METHODS (SAFE FALLBACK)
    # =====================================================

    def get_time(self, timezone: str | None = None) -> str:

        data = self.get_time_raw(timezone)

        if "error" in data:
            return "Saati şu an alamadım."

        return f"Saat şu anda {data.get('time', 'bilinmiyor')}"

    def calculate_expr(self, expression: str) -> str:

        data = self.calculate_raw(expression)

        if "error" in data:
            return "Hesaplayamadım."

        return f"{expression} = {data.get('result', 'bilinmiyor')}"

    def get_weather(self, city: str | None, day_offset: int | None = None) -> str:

        data = self.get_weather_raw(city, day_offset)

        if "error" in data:
            if data["error"] == WeatherError.CITY_NOT_FOUND:
                return "Bu şehri bulamadım. Başka bir şehir adı yazar mısın?"

            return "Hava durumunu şu an alamadım."

        c = data.get("city", city)
        temp = data.get("temp_c", "bilinmiyor")
        desc = data.get("description", "bilinmiyor")
        humidity = data.get("humidity")

        if humidity is None:
            return f"{c}: {temp}°C, {desc}"

        return f"{c}: {temp}°C, {desc} (Nem: %{humidity})"