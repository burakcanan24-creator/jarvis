# core/intent/time_intent.py
from __future__ import annotations

import re


class TimeIntent:
    def __init__(self) -> None:
        self._time_patterns = [
            re.compile(r"\bsaat\s+kaç\b", re.IGNORECASE),
            re.compile(r"\bşu\s+an\s+saat\b", re.IGNORECASE),
            re.compile(r"\bsaat\b.*\bkaç\b", re.IGNORECASE),
            re.compile(r"\bbugün\s+günlerden\s+ne\b", re.IGNORECASE),
            re.compile(r"\bhangi\s+gün\b", re.IGNORECASE),
        ]

    def is_time_query(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        return any(p.search(t) for p in self._time_patterns)