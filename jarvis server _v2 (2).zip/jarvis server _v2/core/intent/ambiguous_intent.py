# core/intent/ambiguous_intent.py
from __future__ import annotations

import re
from core.intent.howto_intent import HowToIntent


class AmbiguousIntent:
    def __init__(self, howto: HowToIntent) -> None:
        self._howto = howto
        self._ambiguous_patterns = [
            re.compile(r"^\s*(bunu|şunu|sun(u|u)|onu)\s+(yap|et)\b", re.IGNORECASE),
            re.compile(r"^\s*(bunu|şunu|onu)\b\s*$", re.IGNORECASE),
            re.compile(r"^\s*(yap|et)\b\s*$", re.IGNORECASE),
        ]

    def is_ambiguous(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False

        if self._howto.is_how_to(t) and not self._howto.has_object_hint(t):
            return True

        return any(p.search(t) for p in self._ambiguous_patterns)