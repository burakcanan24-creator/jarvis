# core/intent/info_intent.py
from __future__ import annotations

import re
from core.intent.howto_intent import HowToIntent


class InfoIntent:
    def __init__(self, howto: HowToIntent) -> None:
        self._howto = howto
        self._info_patterns = [
            re.compile(r"\bkimdir\b", re.IGNORECASE),
            re.compile(r"\bnedir\b", re.IGNORECASE),
            re.compile(r"\bneden\b", re.IGNORECASE),
            re.compile(r"\bniye\b", re.IGNORECASE),
            re.compile(r"\banlat\b", re.IGNORECASE),
            re.compile(r"\baçıkla\b", re.IGNORECASE),
            re.compile(r"\bacikla\b", re.IGNORECASE),
            re.compile(r"\böğret\b", re.IGNORECASE),
            re.compile(r"\bogret\b", re.IGNORECASE),
            re.compile(r"\bne\s+demek\b", re.IGNORECASE),
            re.compile(r"\bmeaning\b", re.IGNORECASE),
            re.compile(r"\bwhat\s+is\b", re.IGNORECASE),
            re.compile(r"\bwho\s+is\b", re.IGNORECASE),
            re.compile(r"\bhow\s+to\b", re.IGNORECASE),
            re.compile(r"\bhow\s+do\s+i\b", re.IGNORECASE),
        ]

    def is_info_query(
        self,
        text: str,
        *,
        is_time: bool,
        is_math: bool,
        is_weather: bool,
        is_who_am_i: bool,
        is_last_question: bool,
        is_self_identity: bool,
        is_capabilities: bool,
        is_assistant_mood: bool,
        is_relationship: bool,
    ) -> bool:
        t = (text or "").strip()
        if not t:
            return False

        if is_time or is_math or is_weather:
            return False
        if is_who_am_i or is_last_question:
            return False
        if is_self_identity or is_capabilities or is_assistant_mood or is_relationship:
            return False

        if self._howto.is_how_to(t):
            return self._howto.has_object_hint(t)

        return any(p.search(t) for p in self._info_patterns)