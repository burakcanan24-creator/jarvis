# core/intent/trivial_intent.py
from __future__ import annotations


class TrivialIntent:
    def __init__(self) -> None:
        self.trivial_inputs = {
            "hm", "hmm", "hıh", "hih",
            "ok", "okay", "tamam", "peki", "olur",
            "evet", "hayır", "hayir",
            "anladım", "anladim",
            "??", "???", ".", "..", "...",
        }

        self._responses = {
            "hm": "Hmm?",
            "hmm": "Evet?",
            "ok": "Tamam.",
            "okay": "Tamam.",
            "tamam": "Tamam.",
            "peki": "Peki.",
            "olur": "Olur.",
            "evet": "Evet.",
            "hayır": "Hayır.",
            "hayir": "Hayır.",
            "anladım": "Anladım.",
            "anladim": "Anladım.",
            ".": ".",
            "..": "...",
            "...": "..."
        }

    def is_trivial(self, text: str) -> bool:
        t = (text or "").strip().lower()
        return t in self.trivial_inputs

    def handle_trivial(self, text: str) -> str:
        t = (text or "").strip().lower()
        return self._responses.get(t, "Hm?")