# core/intent/self_intent.py
from __future__ import annotations

import re


class SelfIntent:
    def __init__(self) -> None:
        self._self_identity_patterns = [
            re.compile(r"^\s*sen\s+kim(sin)?\s*\??\s*$", re.IGNORECASE),
            re.compile(r"^\s*sen\s+nesin\s*\??\s*$", re.IGNORECASE),
            re.compile(r"^\s*jarvis\s+kim(sin)?\s*\??\s*$", re.IGNORECASE),
            re.compile(r"^\s*jarvis\s+nesin\s*\??\s*$", re.IGNORECASE),
            re.compile(r"\bsen\s+kimsin\b", re.IGNORECASE),
            re.compile(r"\bsen\s+nesin\b", re.IGNORECASE),
        ]

        self._capabilities_patterns = [
            re.compile(r"\bne\s+yapabiliyorsun\b", re.IGNORECASE),
            re.compile(r"\bneler\s+yapabiliyorsun\b", re.IGNORECASE),
            re.compile(r"\bne\s+yaparsın\b", re.IGNORECASE),
            re.compile(r"\bneler\s+yaparsın\b", re.IGNORECASE),
            re.compile(r"\bözellik(ler)?in\b", re.IGNORECASE),
            re.compile(r"\bkapasite(n|ler)?\b", re.IGNORECASE),
            re.compile(r"\byardımcı\s+olabilir\s+misin\b", re.IGNORECASE),
        ]

        self._assistant_mood_patterns = [
            re.compile(r"^\s*sen\s+nasılsın\s*\??\s*$", re.IGNORECASE),
            re.compile(r"^\s*nasılsın\s*\??\s*$", re.IGNORECASE),
            re.compile(r"\bsen\s+nasılsın\b", re.IGNORECASE),
        ]

        self._relationship_patterns = [
            re.compile(r"\bbeni\s+tanıyor\s+musun\b", re.IGNORECASE),
            re.compile(r"\bbeni\s+hatırl(ı|i)yor\s+musun\b", re.IGNORECASE),
            re.compile(r"\bbeni\s+seviyor\s+musun\b", re.IGNORECASE),
            re.compile(r"\bbana\s+güven(iyor|ir)\s+musun\b", re.IGNORECASE),
        ]

    def is_self_identity_query(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        return any(p.search(t) for p in self._self_identity_patterns)

    def is_capabilities_query(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        return any(p.search(t) for p in self._capabilities_patterns)

    def is_assistant_mood_query(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        return any(p.search(t) for p in self._assistant_mood_patterns)

    def is_relationship_query(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        return any(p.search(t) for p in self._relationship_patterns)