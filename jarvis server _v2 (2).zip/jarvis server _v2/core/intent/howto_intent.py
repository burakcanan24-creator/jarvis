# core/intent/howto_intent.py
from __future__ import annotations

import re


class HowToIntent:
    def __init__(self) -> None:
        self._how_to_patterns = [
            re.compile(r"\b(nasıl|nasil)\b", re.IGNORECASE),
            re.compile(r"\bhow\s+to\b", re.IGNORECASE),
            re.compile(r"\bhow\s+do\s+i\b", re.IGNORECASE),
        ]

        self._object_hint_words = {
            "chrome", "whatsapp", "wifi", "internet", "dosya", "klasör", "klasor",
            "program", "uygulama", "app", "pc", "bilgisayar", "telefon",
            "ayar", "ayarlar", "settings", "hesap", "account", "mail", "gmail",
            "kamera", "mikrofon", "bluetooth", "yazici", "yazıcı", "pdf",
            "youtube", "spotify", "telegram", "instagram", "facebook",
            "modem", "router", "ağ", "ag", "windows", "android", "ios",
            "site", "web", "tarayıcı", "tarayici", "browser",
        }

        self._how_to_noise_tokens = {
            "nasil", "nasıl",
            "ben", "sen", "biz", "siz",
            "bunu", "şunu", "sunu", "onu",
            "bir", "şey", "sey",
            "mi", "mı", "mu", "mü",
            "yaparim", "yaparım", "yapmak", "yapilir", "yapılır",
            "kurarim", "kurarım", "kurmak", "kurulur",
            "silerim", "silmek", "silinir",
        }

        self._how_to_verbish_re = re.compile(
            r"^(aç|ac)(mak|arım|arim|iyorum|iyorum|ılır|ilir|)|"
            r"^(yap)(mak|arım|arim|ıyorum|iyorum|ılır|ilir|)|"
            r"^(kur)(mak|arım|arim|ulur|ulur|)|"
            r"^(sil)(mek|erim|arım|inir|inir|)|"
            r"^(başlat|baslat)(mak|ırım|irim|ılır|ilir|)|"
            r"^(durdur)(mak|urum|urum|ulur|ulur|)$",
            re.IGNORECASE,
        )

    def is_how_to(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        return any(p.search(t) for p in self._how_to_patterns)

    def has_object_hint(self, text: str) -> bool:
        t = (text or "").strip().lower()
        if not t:
            return False

        if re.search(r"['\"“”].{2,}['\"“”]", t):
            return True

        tokens = re.findall(r"[a-zçğıöşü0-9]+", t, flags=re.IGNORECASE)
        if not tokens:
            return False

        if any(tok in self._object_hint_words for tok in tokens):
            return True

        content_tokens = []
        for tok in tokens:
            if tok in self._how_to_noise_tokens:
                continue
            if self._how_to_verbish_re.match(tok):
                continue
            content_tokens.append(tok)

        return len(content_tokens) >= 1