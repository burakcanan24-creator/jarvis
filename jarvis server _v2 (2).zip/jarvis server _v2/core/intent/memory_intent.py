# core/intent/memory_intent.py
from __future__ import annotations

import re


class MemoryIntent:
    def __init__(self) -> None:
        self._who_am_i_patterns = [
            re.compile(r"^\s*ben\s+kimim\s*\??\s*$", re.IGNORECASE),
            re.compile(r"^\s*ben\s+kimim\s+ki\s*\??\s*$", re.IGNORECASE),
            re.compile(r"^\s*ben\s+kimim\s+ya\s*\??\s*$", re.IGNORECASE),
        ]

        self._last_question_patterns = [
            re.compile(r"\baz\s+önce\s+ne\s+sordum\b", re.IGNORECASE),
            re.compile(r"\baz\s+once\s+ne\s+sordum\b", re.IGNORECASE),
            re.compile(r"\ben\s+son\s+ne\s+sordum\b", re.IGNORECASE),
            re.compile(r"\bson\s+sorum\s+neydi\b", re.IGNORECASE),
            re.compile(r"\bne\s+sormuştum\b", re.IGNORECASE),
            re.compile(r"\bne\s+sormustum\b", re.IGNORECASE),
        ]

    def is_who_am_i(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        return any(p.match(t) for p in self._who_am_i_patterns)

    def is_last_question_query(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        return any(p.search(t) for p in self._last_question_patterns)