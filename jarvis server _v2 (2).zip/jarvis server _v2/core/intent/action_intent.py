# core/intent/action_intent.py
from __future__ import annotations

import re
from core.intent.howto_intent import HowToIntent


class ActionIntent:
    def __init__(self, howto: HowToIntent) -> None:
        self._howto = howto
        self._action_verb_patterns = [
            re.compile(r"\baç\b", re.IGNORECASE),
            re.compile(r"\bkapat\b", re.IGNORECASE),
            re.compile(r"\bkur\b", re.IGNORECASE),
            re.compile(r"\bbaşlat\b", re.IGNORECASE),
            re.compile(r"\bbaslat\b", re.IGNORECASE),
            re.compile(r"\boynat\b", re.IGNORECASE),
            re.compile(r"\bdurdur\b", re.IGNORECASE),
            re.compile(r"\bekle\b", re.IGNORECASE),
            re.compile(r"\bsil\b", re.IGNORECASE),
            re.compile(r"\bdeğiştir\b", re.IGNORECASE),
            re.compile(r"\bdegistir\b", re.IGNORECASE),
            re.compile(r"\bset\b", re.IGNORECASE),
            re.compile(r"\bturn\s+on\b", re.IGNORECASE),
            re.compile(r"\bturn\s+off\b", re.IGNORECASE),
            re.compile(r"\bstart\b", re.IGNORECASE),
            re.compile(r"\bstop\b", re.IGNORECASE),
            re.compile(r"\bdelete\b", re.IGNORECASE),
        ]

    def is_action_request(self, text: str, *, is_time: bool, is_math: bool, is_weather: bool) -> bool:
        t = (text or "").strip()
        if not t:
            return False

        if is_time or is_math or is_weather:
            return False

        if self._howto.is_how_to(t):
            return False

        return any(p.search(t) for p in self._action_verb_patterns)