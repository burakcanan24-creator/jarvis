from __future__ import annotations

import re
import unicodedata
from typing import Optional


class WeatherIntent:
    def __init__(self) -> None:

        self._weather_patterns = [
            re.compile(r"\bhava\s+durumu\b", re.IGNORECASE),
            re.compile(r"\bhava\s+nas[ıi]l\b", re.IGNORECASE),
            re.compile(r"\bweather\b", re.IGNORECASE),
        ]

        self._suffix_cleaner = re.compile(
            r"(da|de|ta|te|dan|den|tan|ten)$",
            re.IGNORECASE,
        )

        self._city_candidate = re.compile(r"[a-zçğıöşü]+", re.IGNORECASE)

        # 🔥 STOP WORDS
        self._stop_words = {
            "yarin", "yarın",
            "bugun", "bugün",
            "hava", "durumu",
            "nasil", "nasıl",
            "hafta", "gelecek",
        }

    # ------------------------------------------------

    def _normalize(self, text: str) -> str:
        t = (text or "").casefold()

        t = unicodedata.normalize("NFKD", t)
        t = "".join(c for c in t if not unicodedata.combining(c))

        t = re.sub(r"[^\w\sçğıöşü]", " ", t)
        t = re.sub(r"\s+", " ", t).strip()

        return t

    # ------------------------------------------------

    def _contains_weather_keyword(self, text: str) -> bool:
        return any(p.search(text) for p in self._weather_patterns)

    # ------------------------------------------------

    def is_weather_query(
        self,
        text: str,
        is_time: bool = False,
        is_math: bool = False,
    ) -> bool:

        t = self._normalize(text)

        if not t:
            return False

        if is_time or is_math:
            return False

        return self._contains_weather_keyword(t)

    # ------------------------------------------------
    # 🔥 CRITICAL FIX
    # Forecast artık WEATHER'SIZ çalışamaz
    # ------------------------------------------------

    def is_forecast_query(self, text: str) -> bool:

        t = self._normalize(text)

        if not self._contains_weather_keyword(t):
            return False

        triggers = ["yarin", "yarın", "hafta", "gelecek", "gun", "gün"]

        return any(word in t for word in triggers)

    # ------------------------------------------------

    def extract_day_offset(self, text: str) -> Optional[int]:

        t = self._normalize(text)

        if not self._contains_weather_keyword(t):
            return None

        if "yarin" in t or "yarın" in t:
            return 1

        if "bugun" in t or "bugün" in t:
            return 0

        return None

    # ------------------------------------------------

    def _clean_suffix(self, word: str) -> str:
        return self._suffix_cleaner.sub("", word)

    def extract_city(self, text: str) -> Optional[str]:

        t = self._normalize(text)

        if not self._contains_weather_keyword(t):
            return None

        candidates = self._city_candidate.findall(t)

        for word in candidates:

            cleaned = self._clean_suffix(word)

            if len(cleaned) < 3:
                continue

            if cleaned in self._stop_words:
                continue

            return cleaned.capitalize()

        return None