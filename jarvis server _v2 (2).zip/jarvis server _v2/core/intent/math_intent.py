# core/intent/math_intent.py
from __future__ import annotations

import re
from typing import Optional


class MathIntent:
    def __init__(self) -> None:
        self._math_cmd_patterns = [
            re.compile(r"\bhesapla\b", re.IGNORECASE),
            re.compile(r"\btopla\b", re.IGNORECASE),
            re.compile(r"\bçıkar\b", re.IGNORECASE),
            re.compile(r"\bçarp\b", re.IGNORECASE),
            re.compile(r"\bböl\b", re.IGNORECASE),
            re.compile(r"\bmatematik\b", re.IGNORECASE),
            re.compile(r"\bcalculate\b", re.IGNORECASE),
            re.compile(r"\bmath\b", re.IGNORECASE),
        ]

        self._pure_expr = re.compile(r"^[\d\+\-\*/%\(\)\.\,\s]+$")
        self._expr_token = re.compile(r"[\d\.\,]+|[\+\-\*/%\(\)]")

    def is_math_query(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False

        if any(p.search(t) for p in self._math_cmd_patterns):
            return True

        if self._pure_expr.match(t) and any(op in t for op in "+-*/%"):
            return True

        return False

    def extract_math_expression(self, text: str) -> Optional[str]:
        t = (text or "").strip()
        if not t:
            return None

        if self._pure_expr.match(t) and any(op in t for op in "+-*/%"):
            return t.replace(" ", "").replace(",", ".")

        tokens = self._expr_token.findall(t)
        if not tokens:
            return None

        expr = "".join(tokens).replace(" ", "").replace(",", ".")
        if not any(op in expr for op in "+-*/%"):
            return None

        return expr or None