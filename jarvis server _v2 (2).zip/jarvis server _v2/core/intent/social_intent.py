# core/intent/social_intent.py
from __future__ import annotations


class SocialIntent:
    def is_greeting(self, text: str) -> bool:
        greetings = {"merhaba", "selam", "hey", "hi", "hello", "slm"}
        return (text or "").strip().lower() in greetings

    def is_goodbye(self, text: str) -> bool:
        goodbyes = {"güle güle", "gule gule", "hoşçakal", "hoşça kal", "bye", "bay"}
        return (text or "").strip().lower() in goodbyes