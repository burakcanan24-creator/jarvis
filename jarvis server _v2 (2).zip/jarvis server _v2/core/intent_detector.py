# core/intent_detector.py - Intent detection (split + safe)
from __future__ import annotations

from typing import Optional

from core.intent.time_intent import TimeIntent
from core.intent.math_intent import MathIntent
from core.intent.weather_intent import WeatherIntent
from core.intent.memory_intent import MemoryIntent
from core.intent.self_intent import SelfIntent
from core.intent.howto_intent import HowToIntent
from core.intent.info_intent import InfoIntent
from core.intent.action_intent import ActionIntent
from core.intent.ambiguous_intent import AmbiguousIntent
from core.intent.trivial_intent import TrivialIntent
from core.intent.social_intent import SocialIntent


class IntentDetector:
    """
    Detects special intents in user input.
    Split version: same public API, less line count, easier to maintain.
    """

    def __init__(self):
        self._time = TimeIntent()
        self._math = MathIntent()
        self._weather = WeatherIntent()

        self._memory = MemoryIntent()
        self._self = SelfIntent()

        self._howto = HowToIntent()
        self._info = InfoIntent(self._howto)
        self._action = ActionIntent(self._howto)
        self._ambiguous = AmbiguousIntent(self._howto)

        self._trivial = TrivialIntent()
        self._social = SocialIntent()

    # ================= TIME =================
    def is_time_query(self, text: str) -> bool:
        return self._time.is_time_query(text)

    # ================= MATH =================
    def is_math_query(self, text: str) -> bool:
        return self._math.is_math_query(text)

    def extract_math_expression(self, text: str) -> Optional[str]:
        return self._math.extract_math_expression(text)

    # ================= WEATHER =================
    def is_weather_query(self, text: str) -> bool:
        return self._weather.is_weather_query(
            text,
            is_time=self.is_time_query(text),
            is_math=self.is_math_query(text),
        )

    def is_forecast_query(self, text: str) -> bool:
        # "yarın?", "bugün hava?" gibi forecast tetikleri
        return self._weather.is_forecast_query(text)

    def extract_day_offset(self, text: str) -> Optional[int]:
        # bugün=0, yarın=1
        return self._weather.extract_day_offset(text)

    def extract_city(self, text: str) -> Optional[str]:
        return self._weather.extract_city(text)

    # ================= MEMORY =================
    def is_who_am_i(self, text: str) -> bool:
        return self._memory.is_who_am_i(text)

    def is_last_question_query(self, text: str) -> bool:
        return self._memory.is_last_question_query(text)

    # ================= SELF / ASSISTANT =================
    def is_self_identity_query(self, text: str) -> bool:
        return self._self.is_self_identity_query(text)

    def is_capabilities_query(self, text: str) -> bool:
        return self._self.is_capabilities_query(text)

    def is_assistant_mood_query(self, text: str) -> bool:
        return self._self.is_assistant_mood_query(text)

    def is_relationship_query(self, text: str) -> bool:
        return self._self.is_relationship_query(text)

    # ================= INFO / ACTION / AMBIGUOUS =================
    def is_info_query(self, text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False

        return self._info.is_info_query(
            t,
            is_time=self.is_time_query(t),
            is_math=self.is_math_query(t),
            is_weather=self.is_weather_query(t),
            is_who_am_i=self.is_who_am_i(t),
            is_last_question=self.is_last_question_query(t),
            is_self_identity=self.is_self_identity_query(t),
            is_capabilities=self.is_capabilities_query(t),
            is_assistant_mood=self.is_assistant_mood_query(t),
            is_relationship=self.is_relationship_query(t),
        )

    def is_action_request(self, text: str) -> bool:
        return self._action.is_action_request(
            text,
            is_time=self.is_time_query(text),
            is_math=self.is_math_query(text),
            is_weather=self.is_weather_query(text),
        )

    def is_ambiguous(self, text: str) -> bool:
        return self._ambiguous.is_ambiguous(text)

    # ================= TRIVIAL =================
    def is_trivial(self, text: str) -> bool:
        return self._trivial.is_trivial(text)

    def handle_trivial(self, text: str) -> str:
        return self._trivial.handle_trivial(text)

    # ================= SOCIAL =================
    def is_greeting(self, text: str) -> bool:
        return self._social.is_greeting(text)

    def is_goodbye(self, text: str) -> bool:
        return self._social.is_goodbye(text)