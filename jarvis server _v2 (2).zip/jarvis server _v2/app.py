from dotenv import load_dotenv
from pathlib import Path
import os

# 🔥 ROOT GARANTİ — cwd bağımlılığı bitti
ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"

load_dotenv(ENV_PATH)

print("✅ DOTENV:", ENV_PATH)
print("✅ WEATHER:", repr(os.getenv("WEATHER_API_KEY")))

from flask import Flask, request, jsonify
from core.agent import JarvisAgent

app = Flask(__name__)
agent = JarvisAgent(memory_path="memory.json")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(force=True) or {}
    session_id = (data.get("session_id") or "default").strip() or "default"
    text = data.get("text", "")

    reply = agent.chat(text, session_id=session_id)

    session = agent.store.get_session(session_id)
    trace = None

    trace_obj = session.get("trace")
    if trace_obj and hasattr(trace_obj, "get_last_decision"):
        trace = trace_obj.get_last_decision()

    return jsonify({
        "reply": reply,
        "trace": trace,
    })


@app.route("/health")
def health():
    return {"status": "ok"}


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=False)